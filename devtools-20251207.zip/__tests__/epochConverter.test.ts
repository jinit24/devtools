import { convertEpochToDate, convertDateToEpoch, getCurrentTimestamp, getCurrentTimestampDetails, detectTimestampFormat } from '@/lib/tools/epochConverter'

describe('Epoch Converter', () => {
  describe('detectTimestampFormat', () => {
    it('should detect seconds (10 digits)', () => {
      expect(detectTimestampFormat(1701234567)).toBe('seconds')
    })

    it('should detect milliseconds (13 digits)', () => {
      expect(detectTimestampFormat(1701234567000)).toBe('milliseconds')
    })

    it('should detect microseconds (16 digits)', () => {
      expect(detectTimestampFormat(1701234567000000)).toBe('microseconds')
    })

    it('should detect nanoseconds (19 digits)', () => {
      expect(detectTimestampFormat(1701234567000000000)).toBe('nanoseconds')
    })
  })

  describe('convertEpochToDate', () => {
    it('should convert seconds timestamp to detailed date info', () => {
      const result = convertEpochToDate('1701234567')
      expect(result).not.toBeNull()
      expect(result?.seconds).toBe(1701234567)
      expect(result?.milliseconds).toBe(1701234567000)
      expect(result?.gmtString).toBeTruthy()
      expect(result?.localString).toBeTruthy()
      expect(result?.isoString).toBeTruthy()
      expect(result?.detectedFormat).toBe('seconds')
    })

    it('should convert milliseconds timestamp to detailed date info', () => {
      const result = convertEpochToDate('1701234567000')
      expect(result).not.toBeNull()
      expect(result?.seconds).toBe(1701234567)
      expect(result?.milliseconds).toBe(1701234567000)
      expect(result?.detectedFormat).toBe('milliseconds')
    })

    it('should convert microseconds timestamp', () => {
      const result = convertEpochToDate('1701234567000000')
      expect(result).not.toBeNull()
      expect(result?.seconds).toBe(1701234567)
      expect(result?.detectedFormat).toBe('microseconds')
    })

    it('should convert nanoseconds timestamp', () => {
      const result = convertEpochToDate('1701234567000000000')
      expect(result).not.toBeNull()
      expect(result?.seconds).toBe(1701234567)
      expect(result?.detectedFormat).toBe('nanoseconds')
    })

    it('should include all timestamp formats', () => {
      const result = convertEpochToDate('1701234567')
      expect(result).not.toBeNull()
      expect(result?.seconds).toBe(1701234567)
      expect(result?.milliseconds).toBe(1701234567 * 1000)
      expect(result?.microseconds).toBe(1701234567 * 1000000)
      expect(result?.nanoseconds).toBe(1701234567 * 1000000000)
    })

    it('should include GMT and local time strings', () => {
      const result = convertEpochToDate('1701234567')
      expect(result).not.toBeNull()
      expect(result?.gmtString).toContain('GMT')
      expect(result?.localString).toBeTruthy()
      expect(result?.utcString).toContain('GMT')
    })

    it('should include ISO 8601 format', () => {
      const result = convertEpochToDate('1701234567')
      expect(result).not.toBeNull()
      expect(result?.isoString).toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)
    })

    it('should include relative time', () => {
      const result = convertEpochToDate('1701234567')
      expect(result).not.toBeNull()
      expect(result?.relativeTime).toBeTruthy()
    })

    it('should handle invalid timestamp', () => {
      const result = convertEpochToDate('invalid')
      expect(result).toBeNull()
    })

    it('should handle empty string', () => {
      const result = convertEpochToDate('')
      expect(result).toBeNull()
    })
  })

  describe('convertDateToEpoch', () => {
    it('should convert valid date to epoch seconds', () => {
      const result = convertDateToEpoch('2023-01-01T00:00:00')
      expect(result).not.toBeNull()
      expect(result).toBeGreaterThan(0)
      expect(typeof result).toBe('number')
    })

    it('should handle invalid date', () => {
      const result = convertDateToEpoch('invalid-date')
      expect(result).toBeNull()
    })

    it('should handle empty string', () => {
      const result = convertDateToEpoch('')
      expect(result).toBeNull()
    })

    it('should return consistent timestamps', () => {
      const result1 = convertDateToEpoch('2023-01-01T00:00:00')
      const result2 = convertDateToEpoch('2023-01-01T00:00:00')
      expect(result1).toBe(result2)
    })
  })

  describe('getCurrentTimestamp', () => {
    it('should return current timestamp as number', () => {
      const result = getCurrentTimestamp()
      expect(typeof result).toBe('number')
      expect(result).toBeGreaterThan(1700000000) // After 2023
    })

    it('should return different values over time', async () => {
      const first = getCurrentTimestamp()
      await new Promise(resolve => setTimeout(resolve, 1100))
      const second = getCurrentTimestamp()
      expect(second).toBeGreaterThan(first)
    })
  })

  describe('getCurrentTimestampDetails', () => {
    it('should return detailed timestamp information', () => {
      const result = getCurrentTimestampDetails()
      expect(result.seconds).toBeTruthy()
      expect(result.milliseconds).toBeTruthy()
      expect(result.microseconds).toBeTruthy()
      expect(result.nanoseconds).toBeTruthy()
      expect(result.gmtString).toBeTruthy()
      expect(result.localString).toBeTruthy()
      expect(result.isoString).toBeTruthy()
      expect(result.utcString).toBeTruthy()
    })

    it('should have consistent conversions', () => {
      const result = getCurrentTimestampDetails()
      // Milliseconds should be close to seconds * 1000 (within 1000ms for rounding)
      expect(result.milliseconds).toBeGreaterThanOrEqual(result.seconds * 1000)
      expect(result.milliseconds).toBeLessThan((result.seconds + 1) * 1000)
      // Microseconds and nanoseconds are based on milliseconds
      expect(result.microseconds).toBe(result.milliseconds * 1000)
      expect(result.nanoseconds).toBe(result.milliseconds * 1000000)
    })

    it('should show relative time as now', () => {
      const result = getCurrentTimestampDetails()
      expect(result.relativeTime).toBe('now')
    })
  })
})

