import {
  encodeURL,
  decodeURL,
  encodeFullURL,
  parseURL,
  buildQueryString,
  validateURL,
} from '@/lib/tools/urlEncoder'

describe('URL Encoder Enhanced', () => {
  const plainText = 'hello world'
  const encodedText = 'hello%20world'
  const fullURL = 'https://example.com/search?q=hello world&lang=en'
  const validURL = 'https://example.com/path?query=value#hash'

  describe('encodeURL', () => {
    it('should encode spaces', () => {
      const result = encodeURL(plainText)
      expect(result).toBe(encodedText)
    })

    it('should encode special characters', () => {
      const special = 'hello&world=test'
      const encoded = encodeURL(special)
      expect(encoded).toContain('%26')
      expect(encoded).toContain('%3D')
    })

    it('should handle empty string', () => {
      const result = encodeURL('')
      expect(result).toBe('')
    })
  })

  describe('decodeURL', () => {
    it('should decode URL-encoded strings', () => {
      const result = decodeURL(encodedText)
      expect(result).toBe(plainText)
    })

    it('should roundtrip encode/decode', () => {
      const original = 'test@example.com?query=value'
      const encoded = encodeURL(original)
      const decoded = decodeURL(encoded)
      expect(decoded).toBe(original)
    })

    it('should handle invalid encoding', () => {
      const result = decodeURL('%ZZ')
      expect(result).toContain('Error')
    })
  })

  describe('encodeFullURL', () => {
    it('should encode full URL preserving structure', () => {
      const result = encodeFullURL(fullURL)
      expect(result).toContain('https://')
      expect(result).toContain('example.com')
    })
  })

  describe('parseURL', () => {
    it('should parse valid URL', () => {
      const parsed = parseURL(validURL)
      expect(parsed).not.toBeNull()
      expect(parsed!.protocol).toBe('https:')
      expect(parsed!.hostname).toBe('example.com')
      expect(parsed!.pathname).toBe('/path')
      expect(parsed!.hash).toBe('#hash')
    })

    it('should extract query parameters', () => {
      const url = 'https://example.com?key1=value1&key2=value2'
      const parsed = parseURL(url)
      expect(parsed!.params).toHaveProperty('key1', 'value1')
      expect(parsed!.params).toHaveProperty('key2', 'value2')
    })

    it('should handle URLs without query params', () => {
      const url = 'https://example.com/path'
      const parsed = parseURL(url)
      expect(parsed).not.toBeNull()
      expect(Object.keys(parsed!.params)).toHaveLength(0)
    })

    it('should return null for invalid URL', () => {
      const parsed = parseURL('not-a-url')
      expect(parsed).toBeNull()
    })

    it('should handle port numbers', () => {
      const url = 'https://example.com:8080/path'
      const parsed = parseURL(url)
      expect(parsed!.port).toBe('8080')
    })
  })

  describe('buildQueryString', () => {
    it('should build query string from params', () => {
      const params = { name: 'John Doe', age: '30' }
      const query = buildQueryString(params)
      expect(query).toContain('name=John%20Doe')
      expect(query).toContain('age=30')
      expect(query).toContain('&')
    })

    it('should handle empty params', () => {
      const query = buildQueryString({})
      expect(query).toBe('')
    })

    it('should encode special characters in values', () => {
      const params = { email: 'test@example.com' }
      const query = buildQueryString(params)
      expect(query).toContain('%40') // @ encoded
    })

    it('should handle multiple params', () => {
      const params = { a: '1', b: '2', c: '3' }
      const query = buildQueryString(params)
      const parts = query.split('&')
      expect(parts).toHaveLength(3)
    })
  })

  describe('validateURL', () => {
    it('should validate correct URLs', () => {
      expect(validateURL('https://example.com')).toBe(true)
      expect(validateURL('http://localhost:3000')).toBe(true)
      expect(validateURL('ftp://files.example.com')).toBe(true)
    })

    it('should reject invalid URLs', () => {
      expect(validateURL('not a url')).toBe(false)
      expect(validateURL('example.com')).toBe(false) // Missing protocol
      expect(validateURL('')).toBe(false)
    })

    it('should handle URLs with paths', () => {
      expect(validateURL('https://example.com/path/to/page')).toBe(true)
    })

    it('should handle URLs with query strings', () => {
      expect(validateURL('https://example.com?query=value')).toBe(true)
    })
  })
})

