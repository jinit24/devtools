import {
  formatJSON,
  minifyJSON,
  sortJSON,
  escapeJSON,
  unescapeJSON,
  validateJSON,
  diffJSON,
  getJSONStats,
} from '@/lib/tools/jsonFormatter'

describe('JSON Formatter Enhanced', () => {
  const validJSON = '{"name":"test","age":30,"active":true}'
  const prettyJSON = JSON.stringify({ name: 'test', age: 30, active: true }, null, 2)
  const invalidJSON = '{name: test}'

  describe('formatJSON', () => {
    it('should format valid JSON with 2 spaces', () => {
      const result = formatJSON(validJSON, 2)
      expect(result.success).toBe(true)
      expect(result.result).toContain('  ')
    })

    it('should handle invalid JSON', () => {
      const result = formatJSON(invalidJSON)
      expect(result.success).toBe(false)
      expect(result.error).toBeDefined()
    })

    it('should format with custom spacing', () => {
      const result = formatJSON(validJSON, 4)
      expect(result.success).toBe(true)
      expect(result.result).toContain('    ')
    })
  })

  describe('minifyJSON', () => {
    it('should minify JSON', () => {
      const result = minifyJSON(prettyJSON)
      expect(result.success).toBe(true)
      expect(result.result).not.toContain('\n')
      expect(result.result).not.toContain('  ')
    })

    it('should handle invalid JSON', () => {
      const result = minifyJSON(invalidJSON)
      expect(result.success).toBe(false)
    })
  })

  describe('sortJSON', () => {
    it('should sort object keys alphabetically', () => {
      const unsorted = '{"zebra":"last","apple":"first","banana":"middle"}'
      const result = sortJSON(unsorted, 2)
      expect(result.success).toBe(true)
      const parsed = JSON.parse(result.result)
      const keys = Object.keys(parsed)
      expect(keys).toEqual(['apple', 'banana', 'zebra'])
    })

    it('should handle nested objects', () => {
      const nested = '{"b":{"y":"last","x":"first"},"a":"first"}'
      const result = sortJSON(nested, 2)
      expect(result.success).toBe(true)
      const parsed = JSON.parse(result.result)
      expect(Object.keys(parsed)).toEqual(['a', 'b'])
      expect(Object.keys(parsed.b)).toEqual(['x', 'y'])
    })

    it('should handle arrays', () => {
      const withArray = '{"items":[3,1,2],"name":"test"}'
      const result = sortJSON(withArray, 2)
      expect(result.success).toBe(true)
      const parsed = JSON.parse(result.result)
      expect(parsed.items).toEqual([3, 1, 2]) // Arrays stay in order
    })
  })

  describe('escapeJSON', () => {
    it('should escape special characters', () => {
      const text = 'Line1\nLine2\tTabbed"Quote"'
      const result = escapeJSON(text)
      expect(result.success).toBe(true)
      expect(result.result).toContain('\\n')
      expect(result.result).toContain('\\t')
      expect(result.result).toContain('\\"')
    })

    it('should escape backslashes', () => {
      const text = 'C:\\Path\\To\\File'
      const result = escapeJSON(text)
      expect(result.success).toBe(true)
      expect(result.result).toContain('\\\\')
    })
  })

  describe('unescapeJSON', () => {
    it('should unescape special characters', () => {
      const escaped = '"Line1\\nLine2\\tTabbed\\"Quote\\""'
      const result = unescapeJSON(escaped)
      expect(result.success).toBe(true)
      expect(result.result).toContain('\n')
      expect(result.result).toContain('\t')
      expect(result.result).toContain('"')
    })

    it('should roundtrip escape/unescape', () => {
      const original = 'Test\nWith\tSpecial"Chars"'
      const escaped = escapeJSON(original)
      const unescaped = unescapeJSON(escaped.result)
      expect(unescaped.success).toBe(true)
      expect(unescaped.result).toBe(original)
    })
  })

  describe('validateJSON', () => {
    it('should validate correct JSON', () => {
      const result = validateJSON(validJSON)
      expect(result.success).toBe(true)
      expect(result.error).toBeUndefined()
    })

    it('should detect invalid JSON', () => {
      const result = validateJSON(invalidJSON)
      expect(result.success).toBe(false)
      expect(result.error).toBeDefined()
    })

    it('should validate arrays', () => {
      const result = validateJSON('[1, 2, 3]')
      expect(result.success).toBe(true)
    })

    it('should validate primitives', () => {
      expect(validateJSON('null').success).toBe(true)
      expect(validateJSON('true').success).toBe(true)
      expect(validateJSON('42').success).toBe(true)
      expect(validateJSON('"string"').success).toBe(true)
    })
  })

  describe('getJSONStats', () => {
    it('should return null for invalid JSON', () => {
      const stats = getJSONStats(invalidJSON)
      expect(stats).toBeNull()
    })

    it('should count lines correctly', () => {
      const stats = getJSONStats(prettyJSON)
      expect(stats).not.toBeNull()
      expect(stats!.lines).toBeGreaterThan(1)
    })

    it('should count keys', () => {
      const json = '{"a":1,"b":2,"c":3}'
      const stats = getJSONStats(json)
      expect(stats!.keys).toBe(3)
    })

    it('should count nested keys', () => {
      const json = '{"outer":{"inner1":1,"inner2":2},"other":3}'
      const stats = getJSONStats(json)
      expect(stats!.keys).toBe(4) // outer, inner1, inner2, other
    })

    it('should calculate depth', () => {
      const shallow = '{"a":1}'
      const deep = '{"a":{"b":{"c":{"d":1}}}}'
      
      const shallowStats = getJSONStats(shallow)
      const deepStats = getJSONStats(deep)
      
      expect(deepStats!.depth).toBeGreaterThan(shallowStats!.depth)
    })

    it('should count objects and arrays', () => {
      const json = '{"obj":{},"arr":[],"nested":{"inner":{}}}'
      const stats = getJSONStats(json)
      
      expect(stats!.objects).toBeGreaterThan(0)
      expect(stats!.arrays).toBe(1)
    })

    it('should get size', () => {
      const stats = getJSONStats(validJSON)
      expect(stats!.size).toBeDefined()
      expect(stats!.size).toContain('Bytes')
    })
  })
})

