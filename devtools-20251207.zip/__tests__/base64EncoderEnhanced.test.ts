import {
  encodeBase64,
  decodeBase64,
  getBase64Stats,
  detectBase64,
} from '@/lib/tools/base64Encoder'

describe('Base64 Encoder Enhanced', () => {
  const plainText = 'Hello, World!'
  const base64Standard = 'SGVsbG8sIFdvcmxkIQ=='
  const base64UrlSafe = 'SGVsbG8sIFdvcmxkIQ'

  describe('encodeBase64', () => {
    it('should encode text to standard Base64', () => {
      const result = encodeBase64(plainText, false)
      expect(result).toBe(base64Standard)
    })

    it('should encode text to URL-safe Base64', () => {
      const result = encodeBase64(plainText, true)
      expect(result).toBe(base64UrlSafe)
    })

    it('should handle empty string', () => {
      const result = encodeBase64('', false)
      expect(result).toBe('')
    })

    it('should handle Unicode characters', () => {
      const unicode = '你好世界' // Hello World in Chinese
      const encoded = encodeBase64(unicode, false)
      expect(encoded).toBeTruthy()
      expect(encoded.length).toBeGreaterThan(0)
    })

    it('should handle special characters', () => {
      const special = 'Test!@#$%^&*()_+-=[]{}|;:,.<>?'
      const encoded = encodeBase64(special, false)
      const decoded = decodeBase64(encoded)
      expect(decoded).toBe(special)
    })
  })

  describe('decodeBase64', () => {
    it('should decode standard Base64', () => {
      const result = decodeBase64(base64Standard)
      expect(result).toBe(plainText)
    })

    it('should decode URL-safe Base64', () => {
      const result = decodeBase64(base64UrlSafe)
      expect(result).toBe(plainText)
    })

    it('should handle invalid Base64', () => {
      const result = decodeBase64('invalid!!!base64')
      expect(result).toContain('Error')
    })

    it('should roundtrip encode/decode', () => {
      const original = 'Test with multiple words and 123 numbers!'
      const encoded = encodeBase64(original, false)
      const decoded = decodeBase64(encoded)
      expect(decoded).toBe(original)
    })
  })

  describe('getBase64Stats', () => {
    it('should calculate size correctly', () => {
      const input = 'Hello'
      const output = encodeBase64(input, false)
      const stats = getBase64Stats(input, output, false)
      
      expect(stats.inputSize).toBeGreaterThan(0)
      expect(stats.outputSize).toBeGreaterThan(stats.inputSize)
      expect(stats.encoding).toBe('standard')
    })

    it('should detect URL-safe encoding', () => {
      const input = 'Hello'
      const output = encodeBase64(input, true)
      const stats = getBase64Stats(input, output, true)
      
      expect(stats.encoding).toBe('url-safe')
    })

    it('should calculate compression ratio', () => {
      const input = 'Test'
      const output = encodeBase64(input, false)
      const stats = getBase64Stats(input, output, false)
      
      expect(parseFloat(stats.compressionRatio)).toBeGreaterThan(1)
    })
  })

  describe('detectBase64', () => {
    it('should detect standard Base64', () => {
      expect(detectBase64(base64Standard)).toBe(true)
    })

    it('should detect URL-safe Base64', () => {
      expect(detectBase64(base64UrlSafe)).toBe(true)
    })

    it('should reject plain text', () => {
      expect(detectBase64(plainText)).toBe(false)
    })

    it('should reject invalid characters', () => {
      expect(detectBase64('invalid!!!chars')).toBe(false)
    })

    it('should handle empty string', () => {
      expect(detectBase64('')).toBe(true) // Empty is technically valid
    })
  })
})

