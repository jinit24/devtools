export interface Base64Stats {
  inputSize: number
  outputSize: number
  compressionRatio: string
  encoding: 'standard' | 'url-safe'
}

export function encodeBase64(input: string, urlSafe: boolean = false): string {
  try {
    const encoded = typeof window !== 'undefined' 
      ? btoa(unescape(encodeURIComponent(input)))
      : Buffer.from(input, 'utf-8').toString('base64')
    
    return urlSafe ? makeUrlSafe(encoded) : encoded
  } catch (error) {
    return 'Error: Invalid input for Base64 encoding'
  }
}

export function decodeBase64(input: string): string {
  try {
    // Handle URL-safe Base64
    const normalized = input.replace(/-/g, '+').replace(/_/g, '/')
    
    const decoded = typeof window !== 'undefined'
      ? decodeURIComponent(escape(atob(normalized)))
      : Buffer.from(normalized, 'base64').toString('utf-8')
    
    return decoded
  } catch (error) {
    return 'Error: Invalid Base64 string'
  }
}

function makeUrlSafe(base64: string): string {
  return base64
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '')
}

export function getBase64Stats(input: string, output: string, urlSafe: boolean = false): Base64Stats {
  const inputSize = new Blob([input]).size
  const outputSize = new Blob([output]).size
  const ratio = inputSize > 0 ? (outputSize / inputSize).toFixed(2) : '0'
  
  return {
    inputSize,
    outputSize,
    compressionRatio: ratio,
    encoding: urlSafe ? 'url-safe' : 'standard',
  }
}

export function detectBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/
  const urlSafeBase64Regex = /^[A-Za-z0-9_-]*$/
  
  return base64Regex.test(input) || urlSafeBase64Regex.test(input)
}
