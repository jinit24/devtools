export interface JWTDecoded {
  header: any
  payload: any
  signature: string
  isValid: boolean
  error?: string
}

export function decodeJWT(token: string): JWTDecoded {
  try {
    const parts = token.split('.')
    
    if (parts.length !== 3) {
      return {
        header: null,
        payload: null,
        signature: '',
        isValid: false,
        error: 'Invalid JWT format. Expected 3 parts separated by dots.',
      }
    }

    const [headerB64, payloadB64, signature] = parts

    // Decode header
    const header = JSON.parse(atob(headerB64.replace(/-/g, '+').replace(/_/g, '/')))
    
    // Decode payload
    const payload = JSON.parse(atob(payloadB64.replace(/-/g, '+').replace(/_/g, '/')))

    // Check expiration
    let isValid = true
    let error: string | undefined

    if (payload.exp) {
      const now = Math.floor(Date.now() / 1000)
      if (payload.exp < now) {
        isValid = false
        error = 'Token has expired'
      }
    }

    return {
      header,
      payload,
      signature,
      isValid,
      error,
    }
  } catch (err) {
    return {
      header: null,
      payload: null,
      signature: '',
      isValid: false,
      error: err instanceof Error ? err.message : 'Failed to decode JWT',
    }
  }
}

export function formatTimestamp(timestamp: number): string {
  return new Date(timestamp * 1000).toLocaleString()
}

