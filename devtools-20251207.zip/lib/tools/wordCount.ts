export interface WordCountStats {
  characters: number
  charactersNoSpaces: number
  words: number
  sentences: number
  paragraphs: number
  lines: number
  readingTime: string
  speakingTime: string
}

export function getWordCountStats(text: string): WordCountStats {
  // Characters
  const characters = text.length
  const charactersNoSpaces = text.replace(/\s/g, '').length

  // Words (split by whitespace, filter empty)
  const words = text.trim() ? text.trim().split(/\s+/).length : 0

  // Sentences (split by . ! ?)
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0).length

  // Paragraphs (split by double newline or more)
  const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0).length

  // Lines
  const lines = text.split(/\n/).length

  // Reading time (average 200 words per minute)
  const readingMinutes = words / 200
  const readingTime = readingMinutes < 1 
    ? '< 1 min' 
    : `${Math.ceil(readingMinutes)} min`

  // Speaking time (average 130 words per minute)
  const speakingMinutes = words / 130
  const speakingTime = speakingMinutes < 1
    ? '< 1 min'
    : `${Math.ceil(speakingMinutes)} min`

  return {
    characters,
    charactersNoSpaces,
    words,
    sentences,
    paragraphs,
    lines,
    readingTime,
    speakingTime,
  }
}

