export interface URLComponents {
  protocol: string
  hostname: string
  port: string
  pathname: string
  search: string
  hash: string
  params: Record<string, string>
}

export function encodeURL(input: string): string {
  try {
    return encodeURIComponent(input)
  } catch (error) {
    return 'Error: Invalid input for URL encoding'
  }
}

export function decodeURL(input: string): string {
  try {
    return decodeURIComponent(input)
  } catch (error) {
    return 'Error: Invalid URL-encoded string'
  }
}

export function encodeFullURL(input: string): string {
  try {
    return encodeURI(input)
  } catch (error) {
    return 'Error: Invalid URL'
  }
}

export function parseURL(input: string): URLComponents | null {
  try {
    const url = new URL(input)
    const params: Record<string, string> = {}
    
    url.searchParams.forEach((value, key) => {
      params[key] = value
    })
    
    return {
      protocol: url.protocol,
      hostname: url.hostname,
      port: url.port,
      pathname: url.pathname,
      search: url.search,
      hash: url.hash,
      params,
    }
  } catch (error) {
    return null
  }
}

export function buildQueryString(params: Record<string, string>): string {
  return Object.entries(params)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&')
}

export function validateURL(input: string): boolean {
  try {
    new URL(input)
    return true
  } catch {
    return false
  }
}
