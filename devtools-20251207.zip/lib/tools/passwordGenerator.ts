export interface PasswordOptions {
  length: number
  uppercase: boolean
  lowercase: boolean
  numbers: boolean
  symbols: boolean
}

export interface PasswordStrength {
  score: number // 0-4
  label: string
  color: string
}

const LOWERCASE = 'abcdefghijklmnopqrstuvwxyz'
const UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
const NUMBERS = '0123456789'
const SYMBOLS = '!@#$%^&*()_+-=[]{}|;:,.<>?'

export function generatePassword(options: PasswordOptions): string {
  let chars = ''
  let password = ''

  if (options.lowercase) chars += LOWERCASE
  if (options.uppercase) chars += UPPERCASE
  if (options.numbers) chars += NUMBERS
  if (options.symbols) chars += SYMBOLS

  if (chars.length === 0) {
    chars = LOWERCASE + UPPERCASE + NUMBERS
  }

  // Ensure at least one of each selected type
  if (options.lowercase) password += LOWERCASE[Math.floor(Math.random() * LOWERCASE.length)]
  if (options.uppercase) password += UPPERCASE[Math.floor(Math.random() * UPPERCASE.length)]
  if (options.numbers) password += NUMBERS[Math.floor(Math.random() * NUMBERS.length)]
  if (options.symbols) password += SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]

  // Fill the rest
  for (let i = password.length; i < options.length; i++) {
    password += chars[Math.floor(Math.random() * chars.length)]
  }

  // Shuffle the password
  return password.split('').sort(() => Math.random() - 0.5).join('')
}

export function calculatePasswordStrength(password: string): PasswordStrength {
  let score = 0

  // Length
  if (password.length >= 8) score++
  if (password.length >= 12) score++
  if (password.length >= 16) score++

  // Character variety
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++
  if (/\d/.test(password)) score++
  if (/[^a-zA-Z0-9]/.test(password)) score++

  // Cap at 4
  score = Math.min(score, 4)

  const labels = ['Very Weak', 'Weak', 'Fair', 'Strong', 'Very Strong']
  const colors = ['red', 'orange', 'yellow', 'lightgreen', 'green']

  return {
    score,
    label: labels[score],
    color: colors[score],
  }
}

export function generateBulkPasswords(count: number, options: PasswordOptions): string[] {
  return Array.from({ length: count }, () => generatePassword(options))
}

