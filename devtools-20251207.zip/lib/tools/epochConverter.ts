export interface TimestampDetails {
  seconds: number
  milliseconds: number
  microseconds: number
  nanoseconds: number
  gmtString: string
  localString: string
  isoString: string
  utcString: string
  relativeTime: string
  detectedFormat: 'seconds' | 'milliseconds' | 'microseconds' | 'nanoseconds'
}

export function detectTimestampFormat(timestamp: number): 'seconds' | 'milliseconds' | 'microseconds' | 'nanoseconds' {
  const digits = timestamp.toString().length
  
  if (digits <= 10) return 'seconds'       // 1234567890
  if (digits <= 13) return 'milliseconds'  // 1234567890123
  if (digits <= 16) return 'microseconds'  // 1234567890123456
  return 'nanoseconds'                     // 1234567890123456789
}

export function convertEpochToDate(epoch: string): TimestampDetails | null {
  try {
    const timestamp = parseInt(epoch)
    if (isNaN(timestamp)) {
      return null
    }
    
    // Auto-detect format based on digit count
    const format = detectTimestampFormat(timestamp)
    let date: Date
    let secondsTimestamp: number
    
    switch (format) {
      case 'nanoseconds':
        secondsTimestamp = Math.floor(timestamp / 1000000000)
        date = new Date(secondsTimestamp * 1000)
        break
      case 'microseconds':
        secondsTimestamp = Math.floor(timestamp / 1000000)
        date = new Date(secondsTimestamp * 1000)
        break
      case 'milliseconds':
        secondsTimestamp = Math.floor(timestamp / 1000)
        date = new Date(timestamp)
        break
      default: // seconds
        secondsTimestamp = timestamp
        date = new Date(timestamp * 1000)
    }
    
    if (isNaN(date.getTime())) {
      return null
    }
    
    return {
      seconds: secondsTimestamp,
      milliseconds: secondsTimestamp * 1000,
      microseconds: secondsTimestamp * 1000000,
      nanoseconds: secondsTimestamp * 1000000000,
      gmtString: date.toUTCString(),
      localString: date.toLocaleString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZoneName: 'short'
      }),
      isoString: date.toISOString(),
      utcString: date.toUTCString(),
      relativeTime: getRelativeTime(date),
      detectedFormat: format
    }
  } catch (error) {
    return null
  }
}

export function convertDateToEpoch(dateString: string): number | null {
  try {
    const date = new Date(dateString)
    if (isNaN(date.getTime())) {
      return null
    }
    return Math.floor(date.getTime() / 1000)
  } catch (error) {
    return null
  }
}

export function getCurrentTimestamp(): number {
  return Math.floor(Date.now() / 1000)
}

export function getCurrentTimestampDetails(): TimestampDetails {
  const now = new Date()
  const seconds = Math.floor(now.getTime() / 1000)
  
  return {
    seconds,
    milliseconds: now.getTime(),
    microseconds: now.getTime() * 1000,
    nanoseconds: now.getTime() * 1000000,
    gmtString: now.toUTCString(),
    localString: now.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    }),
    isoString: now.toISOString(),
    utcString: now.toUTCString(),
    relativeTime: 'now',
    detectedFormat: 'seconds'
  }
}

function getRelativeTime(date: Date): string {
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSeconds = Math.floor(Math.abs(diffMs) / 1000)
  const diffMinutes = Math.floor(diffSeconds / 60)
  const diffHours = Math.floor(diffMinutes / 60)
  const diffDays = Math.floor(diffHours / 24)
  const diffYears = Math.floor(diffDays / 365)
  
  const isPast = diffMs > 0
  
  if (diffSeconds < 60) {
    return isPast ? `${diffSeconds} seconds ago` : `in ${diffSeconds} seconds`
  } else if (diffMinutes < 60) {
    return isPast ? `${diffMinutes} minutes ago` : `in ${diffMinutes} minutes`
  } else if (diffHours < 24) {
    return isPast ? `${diffHours} hours ago` : `in ${diffHours} hours`
  } else if (diffDays < 365) {
    return isPast ? `${diffDays} days ago` : `in ${diffDays} days`
  } else {
    return isPast ? `${diffYears} years ago` : `in ${diffYears} years`
  }
}

