export interface JSONStats {
  lines: number
  depth: number
  keys: number
  objects: number
  arrays: number
  size: string
}

export interface FormatResult {
  success: boolean
  result: string
  error?: string
}

export function formatJSON(json: string, spaces: number = 2): FormatResult {
  try {
    const parsed = JSON.parse(json)
    return {
      success: true,
      result: JSON.stringify(parsed, null, spaces),
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Invalid JSON',
    }
  }
}

export function minifyJSON(json: string): FormatResult {
  try {
    const parsed = JSON.parse(json)
    return {
      success: true,
      result: JSON.stringify(parsed),
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Invalid JSON',
    }
  }
}

export function sortJSON(json: string): FormatResult {
  try {
    const parsed = JSON.parse(json)
    const sorted = sortObjectKeys(parsed)
    return {
      success: true,
      result: JSON.stringify(sorted, null, 2),
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Invalid JSON',
    }
  }
}

function sortObjectKeys(obj: any): any {
  if (Array.isArray(obj)) {
    return obj.map(sortObjectKeys)
  }
  if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj)
      .sort()
      .reduce((result: any, key) => {
        result[key] = sortObjectKeys(obj[key])
        return result
      }, {})
  }
  return obj
}

export function escapeJSON(json: string): FormatResult {
  return {
    success: true,
    result: JSON.stringify(json),
  }
}

export function unescapeJSON(json: string): FormatResult {
  try {
    const unescaped = JSON.parse(json)
    return {
      success: true,
      result: typeof unescaped === 'string' ? unescaped : JSON.stringify(unescaped, null, 2),
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: 'Invalid escaped JSON',
    }
  }
}

export function validateJSON(json: string): FormatResult {
  try {
    JSON.parse(json)
    return {
      success: true,
      result: 'Valid JSON ✓',
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Invalid JSON',
    }
  }
}

export interface JSONDiffResult {
  added: string[]
  removed: string[]
  modified: string[]
  unchanged: string[]
}

export function diffJSON(json1: string, json2: string): FormatResult & { diff?: JSONDiffResult } {
  try {
    const obj1 = JSON.parse(json1)
    const obj2 = JSON.parse(json2)
    
    const diff = compareObjects(obj1, obj2)
    
    return {
      success: true,
      result: JSON.stringify(diff, null, 2),
      diff,
    }
  } catch (error) {
    return {
      success: false,
      result: '',
      error: error instanceof Error ? error.message : 'Invalid JSON in one or both inputs',
    }
  }
}

function compareObjects(obj1: any, obj2: any, path: string = ''): JSONDiffResult {
  const result: JSONDiffResult = {
    added: [],
    removed: [],
    modified: [],
    unchanged: [],
  }

  const keys1 = new Set(Object.keys(obj1 || {}))
  const keys2 = new Set(Object.keys(obj2 || {}))

  // Check for added keys
  keys2.forEach(key => {
    const fullPath = path ? `${path}.${key}` : key
    if (!keys1.has(key)) {
      result.added.push(`${fullPath}: ${JSON.stringify(obj2[key])}`)
    }
  })

  // Check for removed keys
  keys1.forEach(key => {
    const fullPath = path ? `${path}.${key}` : key
    if (!keys2.has(key)) {
      result.removed.push(`${fullPath}: ${JSON.stringify(obj1[key])}`)
    }
  })

  // Check for modified or unchanged keys
  keys1.forEach(key => {
    if (keys2.has(key)) {
      const fullPath = path ? `${path}.${key}` : key
      const val1 = obj1[key]
      const val2 = obj2[key]

      if (typeof val1 === 'object' && val1 !== null && typeof val2 === 'object' && val2 !== null) {
        const nested = compareObjects(val1, val2, fullPath)
        result.added.push(...nested.added)
        result.removed.push(...nested.removed)
        result.modified.push(...nested.modified)
        result.unchanged.push(...nested.unchanged)
      } else if (JSON.stringify(val1) !== JSON.stringify(val2)) {
        result.modified.push(`${fullPath}: ${JSON.stringify(val1)} → ${JSON.stringify(val2)}`)
      } else {
        result.unchanged.push(`${fullPath}: ${JSON.stringify(val1)}`)
      }
    }
  })

  return result
}

export function getJSONStats(json: string): JSONStats | null {
  try {
    const parsed = JSON.parse(json)
    const lines = json.split('\n').length
    const depth = getDepth(parsed)
    const keys = countKeys(parsed)
    const { objects, arrays } = countTypes(parsed)
    const size = formatBytes(new Blob([json]).size)

    return { lines, depth, keys, objects, arrays, size }
  } catch {
    return null
  }
}

function getDepth(obj: any, currentDepth: number = 1): number {
  if (typeof obj !== 'object' || obj === null) return currentDepth
  
  const depths = Object.values(obj).map(value => getDepth(value, currentDepth + 1))
  return Math.max(currentDepth, ...depths)
}

function countKeys(obj: any): number {
  if (typeof obj !== 'object' || obj === null) return 0
  
  let count = Object.keys(obj).length
  Object.values(obj).forEach(value => {
    count += countKeys(value)
  })
  return count
}

function countTypes(obj: any): { objects: number; arrays: number } {
  let objects = 0
  let arrays = 0

  if (Array.isArray(obj)) {
    arrays++
    obj.forEach(item => {
      const nested = countTypes(item)
      objects += nested.objects
      arrays += nested.arrays
    })
  } else if (typeof obj === 'object' && obj !== null) {
    objects++
    Object.values(obj).forEach(value => {
      const nested = countTypes(value)
      objects += nested.objects
      arrays += nested.arrays
    })
  }

  return { objects, arrays }
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}
