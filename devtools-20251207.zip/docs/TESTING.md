# Testing Guide

## Test Coverage

All core tool functions are tested with comprehensive test suites.

### Test Files

1. **`__tests__/epochConverter.test.ts`**
   - ✅ Convert timestamp to date
   - ✅ Convert date to timestamp
   - ✅ Get current timestamp
   - ✅ Handle invalid inputs
   - ✅ Handle edge cases

2. **`__tests__/jsonFormatter.test.ts`**
   - ✅ Format JSON with different indentation
   - ✅ Minify JSON
   - ✅ Validate JSON
   - ✅ Handle invalid JSON
   - ✅ Handle nested structures
   - ✅ Detect common errors

3. **`__tests__/base64Encoder.test.ts`**
   - ✅ Encode to Base64
   - ✅ Decode from Base64
   - ✅ Round-trip encoding
   - ✅ Handle invalid input
   - ✅ Handle special characters

4. **`__tests__/urlEncoder.test.ts`**
   - ✅ Encode URLs
   - ✅ Decode URLs
   - ✅ Round-trip encoding
   - ✅ Handle special characters
   - ✅ Handle international characters

## Running Tests

### Run all tests
```bash
npm test
```

### Run tests in watch mode
```bash
npm run test:watch
```

### Run specific test file
```bash
npm test epochConverter
```

## Test Results (Expected)

```
PASS  __tests__/epochConverter.test.ts
PASS  __tests__/jsonFormatter.test.ts
PASS  __tests__/base64Encoder.test.ts
PASS  __tests__/urlEncoder.test.ts

Test Suites: 4 passed, 4 total
Tests:       40+ passed, 40+ total
```

## What's Tested

### ✅ Core Functionality
- All conversion functions work correctly
- Invalid input handling
- Edge cases covered

### ✅ Error Handling
- Invalid formats return appropriate errors
- Empty inputs handled gracefully
- User-friendly error messages

### ✅ Round-Trip Tests
- Encode → Decode returns original
- No data loss in conversions

## What's NOT Tested (Yet)

- React components (optional)
- UI interactions (optional)
- Integration tests (optional)

For a utility tool website, testing the core logic is most important!

## CI/CD Integration (Future)

Add to GitHub Actions:
```yaml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm test
```

This ensures all tests pass before deployment.

