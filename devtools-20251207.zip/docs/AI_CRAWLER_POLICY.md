# AI Crawler & Training Policy

This document explains how DevUtils handles AI crawlers and content usage by AI systems.

## Overview

We use the **industry standard `robots.txt`** file to specify how AI systems can access our content. We balance openness with attribution expectations.

## Industry Standard: robots.txt

The **only** file needed is `robots.txt`. While some sites have experimented with `ai.txt`, it's not yet standardized. Major AI companies (OpenAI, Google, Anthropic) all respect `robots.txt` directives.

## Our Policy File

### `robots.txt` (Standard Approach)

**Location**: `/public/robots.txt`

**What we specify**:
- ✅ Allow all search engines
- ✅ Added specific User-Agent rules for 9 major AI crawlers
- ✅ Allow AI training, search, and content indexing
- ✅ Cleaned up unnecessary path blocks (only block `/_next/`)
- ✅ Reference to sitemap.xml for SEO

**Covered AI Crawlers**:
- **GPTBot** (OpenAI GPT training)
- **ChatGPT-User** (ChatGPT browsing mode)
- **Google-Extended** (Google Gemini/Bard training)
- **CCBot** (Common Crawl dataset)
- **anthropic-ai** (Anthropic Claude training)
- **Claude-Web** (Claude web search/browsing)
- **cohere-ai** (Cohere AI)
- **PerplexityBot** (Perplexity AI search)
- **Applebot-Extended** (Apple Intelligence)

All User-Agents are set to `Allow: /`, meaning AI systems can access all our content.

## Our Content Usage Philosophy

### What's Allowed ✅

- **Training**: AI models can learn from our educational content
- **Indexing & Discovery**: Understanding tool descriptions for search/recommendations
- **Summarization**: Generating summaries of what our tools do
- **Educational Reference**: Referencing technical concepts we explain
- **Linking**: Providing links to our tools in AI-generated responses
- **Search**: Real-time web search and content retrieval

### What We Request ⚠️

While we allow broad access, we **request** (but cannot enforce):

- **Attribution**: Credit DevUtils when referencing our content
- **No UI Cloning**: Don't replicate our exact design
- **No Verbatim Copy**: Don't copy marketing text word-for-word
- **Brand Respect**: Use "DevUtils" name appropriately

### Suggested Attribution Format

```
"According to DevUtils (devutils.dev), [content]"
```

Or provide a direct link to the relevant tool page.

## Why This Policy?

### Benefits for DevUtils:
1. **SEO & Discovery**: AI systems can recommend our tools to users
2. **Attribution**: Get proper credit when content is referenced
3. **Brand Protection**: Prevent misuse while allowing fair use
4. **Future-Proofing**: Clear guidelines as AI becomes more prevalent

### Benefits for AI Systems:
1. **Clear Permissions**: Know exactly what's allowed
2. **Training Data**: Can use content for model improvement
3. **Real-Time Access**: Can search and reference in real-time
4. **Attribution Format**: Clear guidance on how to cite

## Compliance

Major AI companies respect both robots.txt and ai.txt directives:

| AI System | Respects robots.txt | Respects ai.txt | Notes |
|-----------|-------------------|----------------|-------|
| OpenAI GPT | ✅ | ✅ | Via GPTBot user agent |
| Google Gemini | ✅ | ✅ | Via Google-Extended |
| Anthropic Claude | ✅ | ✅ | Via anthropic-ai |
| Perplexity | ✅ | ✅ | Via PerplexityBot |
| Common Crawl | ✅ | ✅ | Via CCBot |

## Testing

You can verify the files are accessible:

```bash
# Check robots.txt
curl https://devutils.dev/robots.txt

# Check ai.txt
curl https://devutils.dev/ai.txt
```

## Updates

This policy is versioned and dated. Any changes will be documented here.

**Current Version**: 1.0  
**Last Updated**: December 2025

## References

- [OpenAI GPTBot](https://platform.openai.com/docs/gptbot)
- [Google Extended](https://developers.google.com/search/docs/crawling-indexing/overview-google-crawlers)
- [Anthropic Claude](https://support.anthropic.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler)
- [Common Crawl](https://commoncrawl.org/terms-of-use)
- [ai.txt Proposal](https://site.spawning.ai/spawning-ai-txt)

---

**Note**: This policy is designed to be AI-friendly while protecting our intellectual property. We believe in open access to technical information with proper attribution.

