# UI Design Specifications - Developer Tools Suite

## Design Philosophy

**Principles:**
- ⚡ Speed First - Minimal, fast-loading
- 🎯 Function Over Form - Tools work perfectly
- 📱 Mobile First - Perfect on all devices
- 🧹 Clean & Simple - No clutter, no distractions
- 🎨 Professional - Developer-focused aesthetics

---

## Color Palette

```css
/* Primary Colors */
--primary-blue:    #3b82f6;  /* Main brand color */
--primary-dark:    #2563eb;  /* Hover states */
--primary-light:   #dbeafe;  /* Backgrounds */

/* Secondary Colors */
--secondary:       #8b5cf6;  /* Accents */
--success:         #10b981;  /* Success states */
--error:           #ef4444;  /* Error states */
--warning:         #f59e0b;  /* Warnings */

/* Neutrals */
--gray-50:         #f9fafb;  /* Light backgrounds */
--gray-100:        #f3f4f6;  /* Subtle backgrounds */
--gray-200:        #e5e7eb;  /* Borders */
--gray-600:        #4b5563;  /* Secondary text */
--gray-900:        #111827;  /* Primary text */
--white:           #ffffff;  /* Pure white */

/* Syntax Highlighting (for code) */
--code-bg:         #1e293b;  /* Dark background */
--code-text:       #e2e8f0;  /* Light text */
--code-keyword:    #f472b6;  /* Pink */
--code-string:     #34d399;  /* Green */
--code-number:     #fbbf24;  /* Yellow */
```

---

## Typography

```css
/* Font Family */
--font-sans:       'Inter', system-ui, -apple-system, sans-serif;
--font-mono:       'JetBrains Mono', 'Fira Code', monospace;

/* Font Sizes */
--text-xs:         0.75rem;   /* 12px */
--text-sm:         0.875rem;  /* 14px */
--text-base:       1rem;      /* 16px */
--text-lg:         1.125rem;  /* 18px */
--text-xl:         1.25rem;   /* 20px */
--text-2xl:        1.5rem;    /* 24px */
--text-3xl:        1.875rem;  /* 30px */
--text-4xl:        2.25rem;   /* 36px */

/* Font Weights */
--font-normal:     400;
--font-medium:     500;
--font-semibold:   600;
--font-bold:       700;
```

---

## Layout Mockups (ASCII Art)

### 1. Homepage (Tool Directory)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         HEADER (Fixed Top)                          │
│ ┌─────────────────────────────────────────────────────────────────┐ │
│ │                                                                 │ │
│ │  DevUtils          Epoch  JSON  Base64  URL  All Tools   🔍    │ │
│ │                                                                 │ │
│ └─────────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────────┤
│                          MAIN CONTENT                               │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                      HERO SECTION                             │ │
│  │                                                               │ │
│  │            Free Developer Tools                               │ │
│  │                                                               │ │
│  │     Fast, simple tools for developers.                        │ │
│  │     No signup required. 100% free.                            │ │
│  │                                                               │ │
│  │           [Search tools...]                                   │ │
│  │                                                               │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                     AD BANNER (728x90)                        │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  Popular Tools                                                      │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                         │
│  │   🕐     │  │   { }    │  │   ABC    │                         │
│  │  Epoch   │  │   JSON   │  │  Base64  │                         │
│  │ Convert  │  │ Formatter│  │  Encode  │                         │
│  │          │  │          │  │          │                         │
│  │ Convert  │  │ Format & │  │ Encode & │                         │
│  │ Unix...  │  │ beautify │  │ decode...│                         │
│  │          │  │          │  │          │                         │
│  │   [→]    │  │   [→]    │  │   [→]    │                         │
│  └──────────┘  └──────────┘  └──────────┘                         │
│                                                                     │
│  ┌──────────┐  ┌──────────┐                                        │
│  │   🔗     │  │   ✓      │                                        │
│  │   URL    │  │   JSON   │                                        │
│  │  Encode  │  │ Validator│                                        │
│  │          │  │          │                                        │
│  │ Encode & │  │ Validate │                                        │
│  │ decode...│  │ JSON...  │                                        │
│  │          │  │          │                                        │
│  │   [→]    │  │   [→]    │                                        │
│  └──────────┘  └──────────┘                                        │
│                                                                     │
│  JSON Tools                                                         │
│  ─────────────────────────────────────────────────────────────────  │
│  [Similar grid of JSON-related tools]                              │
│                                                                     │
│  Encoding Tools                                                     │
│  ─────────────────────────────────────────────────────────────────  │
│  [Similar grid of encoding tools]                                  │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                         FOOTER                                      │
│ ┌─────────────────────────────────────────────────────────────────┐ │
│ │                                                                 │ │
│ │  DevUtils                                                       │ │
│ │                                                                 │ │
│ │  Tools         Resources        Legal                           │ │
│ │  • Epoch       • Blog           • Privacy                       │ │
│ │  • JSON        • Docs           • Terms                         │ │
│ │  • Base64      • API            • Contact                       │ │
│ │                                                                 │ │
│ │  © 2024 DevUtils. All rights reserved.                          │ │
│ │                                                                 │ │
│ └─────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

### 2. Individual Tool Page (Epoch Converter Example)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         HEADER (Same)                               │
│  DevUtils          Epoch  JSON  Base64  URL  All Tools   🔍        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                     AD BANNER (728x90)                        │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌────────────────────┬──────────────────────────────────────────┐ │
│  │                    │                                          │ │
│  │  MAIN TOOL AREA    │        SIDEBAR                           │ │
│  │   (75% width)      │        (25% width)                       │ │
│  │                    │                                          │ │
│  │ ┌────────────────┐ │  ┌────────────────────────────────────┐ │ │
│  │ │                │ │  │  AD SIDEBAR (300x250)              │ │ │
│  │ │  Epoch         │ │  │                                    │ │ │
│  │ │  Converter     │ │  │  [Advertisement]                   │ │ │
│  │ │                │ │  │                                    │ │ │
│  │ └────────────────┘ │  │                                    │ │ │
│  │                    │  │                                    │ │ │
│  │ Current Timestamp  │  └────────────────────────────────────┘ │ │
│  │ ┌────────────────┐ │                                          │ │
│  │ │  1701234567    │ │  Related Tools                           │ │
│  │ │  [Copy]        │ │  ─────────────────                       │ │
│  │ └────────────────┘ │                                          │ │
│  │                    │  ┌──────────────┐                        │ │
│  │ Unix Timestamp     │  │ JSON         │                        │ │
│  │ ┌────────────────┐ │  │ Formatter    │                        │ │
│  │ │ 1701234567     │ │  │    [→]       │                        │ │
│  │ └────────────────┘ │  └──────────────┘                        │ │
│  │    [Convert]       │                                          │ │
│  │                    │  ┌──────────────┐                        │ │
│  │ Result:            │  │ Base64       │                        │ │
│  │ ┌────────────────┐ │  │ Encoder      │                        │ │
│  │ │ Dec 1, 2024    │ │  │    [→]       │                        │ │
│  │ │ 10:30 AM       │ │  └──────────────┘                        │ │
│  │ │                │ │                                          │ │
│  │ │   [Copy] [⬇]   │ │  ┌──────────────┐                        │ │
│  │ └────────────────┘ │  │ URL          │                        │ │
│  │                    │  │ Encoder      │                        │ │
│  │ ─────────────────  │  │    [→]       │                        │ │
│  │                    │  └──────────────┘                        │ │
│  │ Date to Timestamp  │                                          │ │
│  │ ┌────────────────┐ │                                          │ │
│  │ │ [Date Picker]  │ │                                          │ │
│  │ └────────────────┘ │                                          │ │
│  │    [Convert]       │                                          │ │
│  │                    │                                          │ │
│  │ Result:            │                                          │ │
│  │ ┌────────────────┐ │                                          │ │
│  │ │ 1701234567     │ │                                          │ │
│  │ │   [Copy] [⬇]   │ │                                          │ │
│  │ └────────────────┘ │                                          │ │
│  │                    │                                          │ │
│  └────────────────────┴──────────────────────────────────────────┘ │
│                                                                     │
│  What is Epoch Time?                                                │
│  ─────────────────────────────────────────────────────────────────  │
│  Epoch time (also called Unix timestamp) is the number of          │
│  seconds since January 1, 1970, 00:00:00 UTC. It's widely          │
│  used in programming to represent dates and times as a             │
│  single number...                                                   │
│  [Read more]                                                        │
│                                                                     │
│  How to Use This Tool                                               │
│  ─────────────────────────────────────────────────────────────────  │
│  1. Paste your Unix timestamp in the input field                   │
│  2. Click "Convert" to see the human-readable date                 │
│  3. Copy the result with one click                                 │
│                                                                     │
│  Common Use Cases                                                   │
│  ─────────────────────────────────────────────────────────────────  │
│  • Debugging API timestamps                                        │
│  • Converting server log timestamps                                │
│  • Working with database timestamps                                │
│                                                                     │
│  Frequently Asked Questions                                         │
│  ─────────────────────────────────────────────────────────────────  │
│  Q: What is the current Unix timestamp?                            │
│  A: The current Unix timestamp is 1701234567...                    │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                     AD BANNER (728x90)                        │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                         FOOTER (Same)                               │
└─────────────────────────────────────────────────────────────────────┘
```

### 3. Mobile View (Tool Page)

```
┌───────────────────┐
│  ☰  DevUtils   🔍 │
├───────────────────┤
│                   │
│ ┌───────────────┐ │
│ │  AD (320x50)  │ │
│ └───────────────┘ │
│                   │
│ Epoch Converter   │
│ ─────────────────  │
│                   │
│ Current Timestamp │
│ ┌───────────────┐ │
│ │ 1701234567    │ │
│ │    [Copy]     │ │
│ └───────────────┘ │
│                   │
│ Unix Timestamp    │
│ ┌───────────────┐ │
│ │ 1701234567    │ │
│ └───────────────┘ │
│   [Convert]       │
│                   │
│ Result:           │
│ ┌───────────────┐ │
│ │ Dec 1, 2024   │ │
│ │ 10:30 AM      │ │
│ │  [Copy] [⬇]   │ │
│ └───────────────┘ │
│                   │
│ ─────────────────  │
│                   │
│ Date to Timestamp │
│ ┌───────────────┐ │
│ │[Date Picker]  │ │
│ └───────────────┘ │
│   [Convert]       │
│                   │
│ What is Epoch?    │
│ ─────────────────  │
│ Epoch time is...  │
│                   │
│ Related Tools     │
│ ─────────────────  │
│ • JSON Formatter  │
│ • Base64 Encoder  │
│                   │
│ ┌───────────────┐ │
│ │  AD (320x50)  │ │
│ └───────────────┘ │
│                   │
├───────────────────┤
│ Footer            │
└───────────────────┘
```

---

## Component Specifications

### 1. Tool Card (Homepage)

```
┌────────────────────────────┐
│         ICON (72px)        │  ← Large, clear icon
│                            │
│       Tool Name            │  ← 18px, semibold
│                            │
│  Short description text    │  ← 14px, gray-600
│  that explains what the    │
│  tool does clearly         │
│                            │
│      ┌──────────┐          │
│      │   [Go →] │          │  ← Primary button
│      └──────────┘          │
└────────────────────────────┘

Specs:
- Card: white bg, rounded-lg, shadow-md
- Hover: shadow-lg, slight scale (1.02)
- Padding: 24px
- Border: 1px gray-200
- Transition: all 200ms
```

### 2. Input Field

```
┌────────────────────────────────────┐
│ Label Text                    ⓘ   │  ← 14px, medium
├────────────────────────────────────┤
│                                    │
│  Placeholder text...               │  ← 16px input
│                                    │
└────────────────────────────────────┘

Specs:
- Height: 48px
- Border: 1px gray-300
- Border radius: 8px
- Focus: primary-blue border, shadow
- Font: mono for code inputs
- Padding: 12px 16px
```

### 3. Button Styles

**Primary Button:**
```
┌──────────────┐
│   Convert    │  ← White text, primary-blue bg
└──────────────┘

Specs:
- Height: 48px
- Padding: 12px 24px
- Border radius: 8px
- Font: 16px, semibold
- Hover: primary-dark bg
- Active: scale(0.98)
```

**Secondary Button (Copy, Download):**
```
┌────────┐
│  Copy  │  ← Primary-blue text, gray-100 bg
└────────┘

Specs:
- Height: 40px
- Padding: 8px 16px
- Border: 1px primary-blue
- Border radius: 6px
- Font: 14px, medium
```

### 4. Result Display

```
┌────────────────────────────────────┐
│  Result                            │  ← 14px label
├────────────────────────────────────┤
│                                    │
│  1234567890                        │  ← 18px, mono
│                                    │
│    [Copy]  [Download]  [Clear]     │  ← Actions
└────────────────────────────────────┘

Specs:
- Background: gray-50
- Border: 1px gray-200
- Border radius: 8px
- Padding: 16px
- Font: monospace for code/results
```

---

## Real UI Code Examples

### Tool Card Component

```tsx
<div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 hover:scale-102 p-6 border border-gray-200">
  <div className="text-5xl mb-4 text-center">🕐</div>
  <h3 className="text-xl font-semibold text-gray-900 mb-2 text-center">
    Epoch Converter
  </h3>
  <p className="text-sm text-gray-600 mb-4 text-center">
    Convert Unix timestamps to dates and dates to timestamps instantly
  </p>
  <Link 
    href="/epoch-converter"
    className="block w-full px-6 py-3 bg-primary-blue text-white rounded-lg text-center font-semibold hover:bg-primary-dark transition-colors"
  >
    Use Tool →
  </Link>
</div>
```

### Input Component

```tsx
<div className="space-y-2">
  <label className="block text-sm font-medium text-gray-700">
    Unix Timestamp
    <span className="ml-1 text-gray-400" title="Help text">ⓘ</span>
  </label>
  <input
    type="text"
    value={input}
    onChange={(e) => setInput(e.target.value)}
    placeholder="1701234567"
    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-blue focus:border-primary-blue outline-none transition-all font-mono text-base"
  />
</div>
```

### Result Display

```tsx
<div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
  <div className="flex items-center justify-between mb-2">
    <span className="text-sm font-medium text-gray-700">Result</span>
    <div className="flex gap-2">
      <button className="px-3 py-1 text-sm border border-primary-blue text-primary-blue rounded hover:bg-primary-blue hover:text-white transition-colors">
        Copy
      </button>
      <button className="px-3 py-1 text-sm border border-gray-300 text-gray-700 rounded hover:bg-gray-100 transition-colors">
        Download
      </button>
    </div>
  </div>
  <div className="font-mono text-lg text-gray-900">
    {result}
  </div>
</div>
```

---

## Responsive Breakpoints

```css
/* Mobile First Approach */
/* Mobile: Default (< 640px) */
.container { max-width: 100%; padding: 1rem; }

/* Tablet: sm (≥ 640px) */
@media (min-width: 640px) {
  .container { max-width: 640px; }
}

/* Laptop: md (≥ 768px) */
@media (min-width: 768px) {
  .container { max-width: 768px; }
  .grid { grid-template-columns: repeat(2, 1fr); }
}

/* Desktop: lg (≥ 1024px) */
@media (min-width: 1024px) {
  .container { max-width: 1024px; }
  .grid { grid-template-columns: repeat(3, 1fr); }
  .sidebar { display: block; } /* Show sidebar */
}

/* Wide: xl (≥ 1280px) */
@media (min-width: 1280px) {
  .container { max-width: 1280px; }
}
```

---

## Ad Placement Strategy

### Desktop Layout
```
┌─────────────────────────────────────┐
│        Top Banner (728x90)          │ ← High visibility
├─────────────────────┬───────────────┤
│                     │               │
│   Main Tool Area    │   Sidebar     │
│                     │   (300x250)   │ ← Non-intrusive
│                     │               │
│                     │               │
│                     │  Related      │
│                     │  Tools        │
└─────────────────────┴───────────────┘
│     Bottom Banner (728x90)          │ ← After content
└─────────────────────────────────────┘
```

### Mobile Layout
```
┌─────────────┐
│ Anchor Ad   │ ← Fixed bottom (320x50)
├─────────────┤
│ Top Banner  │ ← (320x50)
│             │
│ Tool        │
│ Content     │
│             │
│ Related     │
│ Tools       │
│             │
│ Bottom Ad   │ ← (320x50)
└─────────────┘
```

---

## Animation & Interactions

### Hover Effects
```css
/* Cards */
.card:hover {
  transform: scale(1.02);
  box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

/* Buttons */
.button:hover {
  background: var(--primary-dark);
  transform: translateY(-1px);
}

.button:active {
  transform: scale(0.98);
}

/* Links */
.link:hover {
  color: var(--primary-blue);
  text-decoration: underline;
}
```

### Loading States
```tsx
<button disabled className="opacity-50 cursor-not-allowed">
  <svg className="animate-spin h-5 w-5 mr-2" />
  Converting...
</button>
```

### Success/Error States
```tsx
/* Success */
<div className="bg-green-50 border border-green-200 text-green-800 p-4 rounded">
  ✓ Copied to clipboard!
</div>

/* Error */
<div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded">
  ✗ Invalid input format
</div>
```

---

## Dark Mode (Optional - Future)

```css
/* Light Mode (Default) */
:root {
  --bg-primary: #ffffff;
  --bg-secondary: #f9fafb;
  --text-primary: #111827;
  --text-secondary: #6b7280;
}

/* Dark Mode */
@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: #1f2937;
    --bg-secondary: #111827;
    --text-primary: #f9fafb;
    --text-secondary: #d1d5db;
  }
}
```

---

## Accessibility

### ARIA Labels
```tsx
<button aria-label="Copy result to clipboard">
  Copy
</button>

<input 
  aria-label="Unix timestamp input"
  aria-describedby="timestamp-help"
/>
```

### Keyboard Navigation
```css
/* Focus visible for keyboard users */
.button:focus-visible {
  outline: 2px solid var(--primary-blue);
  outline-offset: 2px;
}
```

### Color Contrast
- Text on white: 4.5:1 minimum (WCAG AA)
- Buttons: High contrast
- Links: Clearly distinguishable

---

## Performance Optimizations

### Image Optimization
```tsx
/* Use SVG for icons (scalable, small) */
<svg className="w-16 h-16">...</svg>

/* Or emoji (zero bytes!) */
<div className="text-5xl">🕐</div>
```

### CSS Optimization
```css
/* Use Tailwind's JIT mode (only includes used classes) */
/* Result: ~10KB CSS instead of 3MB */
```

### JS Optimization
```tsx
/* Lazy load heavy components */
const JsonDiff = dynamic(() => import('./JsonDiff'), {
  loading: () => <div>Loading...</div>
})
```

---

## Final Design Summary

**Look & Feel:**
- 🎨 Clean, modern, professional
- ⚡ Fast and responsive
- 📱 Mobile-first design
- 🎯 Function-focused (tools are the hero)
- 💼 Developer-oriented aesthetics

**Color Scheme:**
- Primary: Blue (#3b82f6) - Professional, trustworthy
- Accent: Purple (#8b5cf6) - Modern touch
- Neutrals: Gray scale - Clean, minimal

**Typography:**
- Sans-serif: Inter (clean, readable)
- Monospace: JetBrains Mono (for code/results)

**Layout:**
- Desktop: Sidebar layout (tool + sidebar ads)
- Mobile: Stacked layout (full width)
- Responsive: 5 breakpoints

**No Custom Backend:**
- ✅ 100% frontend (Next.js static export)
- ✅ All processing in browser
- ✅ No server costs
- ✅ Deployed to Vercel CDN
- ✅ Instant, fast results

Ready to build this? 🚀

