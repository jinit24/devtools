# Google AdSense Implementation Plan

Comprehensive guide to adding Google AdSense to DevUtils for monetization.

## Overview

This plan outlines how to integrate Google AdSense into the DevUtils site to generate revenue while maintaining a great user experience.

---

## Phase 1: Pre-Approval Preparation (Week 1)

### 1.1 Site Readiness Checklist

Before applying for AdSense, ensure the site meets all requirements:

#### ✅ Content Requirements
- [x] **Original Content**: All tool descriptions and educational content is unique
- [x] **Sufficient Content**: 9 tools with detailed documentation
- [x] **Value to Users**: Actual working tools, not just informational pages
- [x] **Privacy Policy**: ❌ NEED TO ADD (required by AdSense)
- [x] **About Page**: ❌ NEED TO ADD (recommended)
- [x] **Contact Information**: ❌ NEED TO ADD (required)

#### ✅ Technical Requirements
- [x] **Custom Domain**: Need to purchase devutils.dev or similar
- [x] **SSL Certificate**: Vercel provides this automatically
- [x] **Mobile Responsive**: ✅ Already implemented
- [x] **Fast Loading**: ✅ Already optimized
- [x] **No Broken Links**: ✅ All links work

#### ✅ Design Requirements
- [x] **Professional Design**: ✅ Clean minimalist design
- [x] **Easy Navigation**: ✅ Header navigation implemented
- [x] **No Copyright Violations**: ✅ All original content
- [x] **Family-Safe**: ✅ Developer tools are safe

### 1.2 Required Pages to Add

Create these pages before applying:

#### `/privacy` - Privacy Policy
```typescript
// app/privacy/page.tsx
export const metadata = {
  title: 'Privacy Policy | DevUtils',
  description: 'Privacy policy for DevUtils - how we handle your data',
}

export default function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <h1>Privacy Policy</h1>
      <p>Last updated: [Date]</p>
      
      <h2>Data Collection</h2>
      <p>All tools run 100% client-side. We do not collect, store, or transmit any of your input data.</p>
      
      <h2>Analytics</h2>
      <p>We use Google Analytics to understand site usage. This collects anonymous data about page views and user behavior.</p>
      
      <h2>Advertising</h2>
      <p>We use Google AdSense to display advertisements. Google may use cookies to show relevant ads.</p>
      
      <h2>Cookies</h2>
      <p>We use cookies for:
        - Analytics (Google Analytics)
        - Advertising (Google AdSense)
        - Dark mode preference
      </p>
      
      <h2>Third-Party Services</h2>
      <p>Google Analytics, Google AdSense</p>
      
      <h2>Contact</h2>
      <p>For privacy questions: [email]</p>
    </div>
  )
}
```

#### `/about` - About Page
```typescript
// app/about/page.tsx
export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <h1>About DevUtils</h1>
      <p>DevUtils is a collection of free, open-source developer tools designed to make your daily development tasks easier.</p>
      
      <h2>Our Mission</h2>
      <p>Provide fast, secure, and easy-to-use tools for developers worldwide—completely free and 100% client-side.</p>
      
      <h2>Why We Built This</h2>
      <p>We noticed developers constantly searching for simple utilities like JSON formatters and epoch converters. We wanted to create a single place with all these tools, beautifully designed and privacy-focused.</p>
      
      <h2>Privacy First</h2>
      <p>All our tools run entirely in your browser. Your data never touches our servers.</p>
    </div>
  )
}
```

#### `/contact` - Contact Page
```typescript
// app/contact/page.tsx
export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <h1>Contact Us</h1>
      <p>Have questions or feedback about DevUtils?</p>
      
      <h2>Email</h2>
      <p>hello@devutils.dev</p>
      
      <h2>GitHub</h2>
      <p>Open an issue: <a href="https://github.com/[your-repo]/issues">GitHub Issues</a></p>
      
      <h2>Feedback</h2>
      <p>We'd love to hear your suggestions for new tools or improvements!</p>
    </div>
  )
}
```

---

## Phase 2: Domain & Deployment (Week 1-2)

### 2.1 Purchase Domain

**Recommended domains** (check availability):
1. `devutils.dev` (Developer-focused TLD)
2. `devutils.io` (Popular for tech)
3. `devkit.tools`
4. `toolsfordev.com`

**Where to buy**:
- Namecheap ($10-15/year)
- Google Domains
- Cloudflare Registrar (cheapest)

### 2.2 Deploy to Production

1. Push code to GitHub
2. Deploy to Vercel
3. Connect custom domain in Vercel settings
4. Verify SSL is active (automatic with Vercel)
5. Update all URLs in metadata to use production domain

---

## Phase 3: AdSense Application (Week 2)

### 3.1 Apply for AdSense

1. **Go to**: https://www.google.com/adsense
2. **Sign in** with Google account
3. **Enter your site URL**: https://devutils.dev
4. **Provide details**:
   - Country
   - Payment address
   - Phone number
5. **Accept terms**
6. **Add AdSense code** to your site (provided by Google)

### 3.2 Add AdSense Verification Code

Google will provide a code snippet. Add it to `app/layout.tsx`:

```typescript
// app/layout.tsx
<head>
  {/* AdSense verification - ADD BEFORE APPLYING */}
  <script
    async
    src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
    crossOrigin="anonymous"
  />
</head>
```

### 3.3 Wait for Approval

- **Timeline**: Usually 1-2 weeks
- **Check status**: In AdSense dashboard
- **Common rejections**:
  - Not enough content → Add more tools
  - Low-value content → Add more educational content
  - Policy violations → Ensure compliance

---

## Phase 4: Ad Implementation (After Approval)

### 4.1 Create Ad Components

#### `components/ads/AdSenseScript.tsx`
```typescript
'use client'

import Script from 'next/script'

export default function AdSenseScript() {
  const ADSENSE_ID = process.env.NEXT_PUBLIC_ADSENSE_ID

  if (!ADSENSE_ID) return null

  return (
    <Script
      async
      src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_ID}`}
      crossOrigin="anonymous"
      strategy="afterInteractive"
    />
  )
}
```

#### `components/ads/AdUnit.tsx`
```typescript
'use client'

import { useEffect } from 'react'

interface AdUnitProps {
  slot: string
  format?: 'auto' | 'rectangle' | 'horizontal' | 'vertical'
  responsive?: boolean
  className?: string
}

export default function AdUnit({ 
  slot, 
  format = 'auto', 
  responsive = true,
  className = '' 
}: AdUnitProps) {
  useEffect(() => {
    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({})
    } catch (err) {
      console.error('AdSense error:', err)
    }
  }, [])

  return (
    <div className={`ad-container ${className}`}>
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client={process.env.NEXT_PUBLIC_ADSENSE_ID}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive.toString()}
      />
    </div>
  )
}
```

### 4.2 Strategic Ad Placements

#### Homepage (`app/page.tsx`)
```typescript
import AdUnit from '@/components/ads/AdUnit'

export default function Home() {
  return (
    <>
      {/* Top banner ad - after hero */}
      <AdUnit slot="1234567890" format="horizontal" className="my-8" />
      
      {/* Tool grid */}
      <ToolsGrid />
      
      {/* In-content ad - between sections */}
      <AdUnit slot="2345678901" format="rectangle" className="my-12" />
      
      {/* Features section */}
      <FeaturesSection />
    </>
  )
}
```

#### Tool Pages (e.g., `app/epoch-converter/page.tsx`)
```typescript
export default function EpochConverterPage() {
  return (
    <div>
      <h1>Epoch Converter</h1>
      
      {/* Sidebar ad */}
      <div className="grid grid-cols-4 gap-8">
        <div className="col-span-3">
          <EpochConverter />
        </div>
        <div className="col-span-1">
          <AdUnit slot="3456789012" format="vertical" />
        </div>
      </div>
      
      {/* Bottom ad - after educational content */}
      <EducationalContent />
      <AdUnit slot="4567890123" format="horizontal" className="mt-12" />
    </div>
  )
}
```

### 4.3 Recommended Ad Positions

**Best performing ad placements**:

1. **Top Banner** (Above tools, below header)
   - Format: Horizontal (728x90 or responsive)
   - Visibility: High
   - Revenue: High

2. **Sidebar** (Desktop only)
   - Format: Vertical (300x600 or 160x600)
   - Visibility: Medium
   - Revenue: Medium

3. **In-Content** (Between sections)
   - Format: Rectangle (300x250)
   - Visibility: High
   - Revenue: Very High

4. **Bottom** (After educational content)
   - Format: Horizontal
   - Visibility: Medium
   - Revenue: Low-Medium

**AVOID**:
- ❌ Too many ads (max 3 per page)
- ❌ Ads that cover content
- ❌ Ads before the tool (bad UX)
- ❌ Popup ads (against policy)

---

## Phase 5: Optimization (Ongoing)

### 5.1 Monitor Performance

**Key Metrics**:
- **RPM (Revenue Per Mille)**: Revenue per 1,000 impressions
- **CTR (Click-Through Rate)**: % of users who click ads
- **CPC (Cost Per Click)**: Revenue per ad click

**Target Benchmarks**:
- RPM: $5-15 for developer tools
- CTR: 1-3%
- CPC: $0.50-2.00

### 5.2 A/B Testing

Test different ad placements:
- Top vs. bottom
- Sidebar vs. in-content
- 2 ads vs. 3 ads per page

### 5.3 Ad Balance

Use Google's "Ad Balance" feature to show fewer ads while maintaining revenue (filters low-paying ads).

---

## Revenue Projections

### Conservative Estimate

**Assumptions**:
- 10,000 monthly visitors (after 6 months of SEO)
- 2 ads per page
- 3 pages per visit
- RPM: $5 (conservative for developer tools)

**Calculation**:
```
10,000 visitors × 3 pages = 30,000 page views
30,000 × 2 ads = 60,000 ad impressions
60,000 / 1,000 × $5 RPM = $300/month
```

### Growth Projections

| Month | Visitors | Page Views | Revenue (RPM $5) | Revenue (RPM $10) |
|-------|----------|------------|------------------|-------------------|
| 3     | 2,000    | 6,000      | $60              | $120              |
| 6     | 10,000   | 30,000     | $300             | $600              |
| 12    | 50,000   | 150,000    | $1,500           | $3,000            |
| 24    | 200,000  | 600,000    | $6,000           | $12,000           |

---

## Environment Variables

Add to `.env.local`:

```bash
# Google AdSense
NEXT_PUBLIC_ADSENSE_ID=ca-pub-XXXXXXXXXXXXXXXX

# Ad Slots (get from AdSense dashboard)
NEXT_PUBLIC_AD_SLOT_TOP_BANNER=1234567890
NEXT_PUBLIC_AD_SLOT_SIDEBAR=2345678901
NEXT_PUBLIC_AD_SLOT_IN_CONTENT=3456789012
NEXT_PUBLIC_AD_SLOT_BOTTOM=4567890123
```

---

## Compliance & Best Practices

### AdSense Policies

**Must follow**:
- ✅ No clicking your own ads
- ✅ No asking users to click ads
- ✅ No misleading ad placements
- ✅ No ads on error pages
- ✅ Privacy policy must mention ads
- ✅ Cookie consent (GDPR if EU traffic)

### User Experience

**Balance revenue with UX**:
- Keep ads non-intrusive
- Don't block content with ads
- Maintain fast page speed
- Ensure mobile experience isn't degraded

---

## Timeline Summary

| Phase | Duration | Key Tasks |
|-------|----------|-----------|
| **Phase 1** | Week 1 | Add Privacy/About/Contact pages |
| **Phase 2** | Week 1-2 | Purchase domain, deploy to production |
| **Phase 3** | Week 2 | Apply for AdSense, wait for approval |
| **Phase 4** | Week 3-4 | Implement ad components, test placements |
| **Phase 5** | Ongoing | Monitor, optimize, A/B test |

**Total time to first revenue**: 3-4 weeks

---

## Next Steps

1. ✅ Add Privacy Policy page
2. ✅ Add About page
3. ✅ Add Contact page
4. ✅ Update Footer with links to these pages
5. ⏳ Purchase domain
6. ⏳ Deploy to production
7. ⏳ Apply for AdSense
8. ⏳ Wait for approval
9. ⏳ Implement ads
10. ⏳ Monitor & optimize

Would you like me to implement the required pages (Privacy, About, Contact) now?

