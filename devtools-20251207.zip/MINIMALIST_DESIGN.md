# 🎨 Modern Minimalist Design System

## ✨ Design Philosophy

**Inspired by:** Linear, Vercel, Apple
**Core Principles:**
- Generous white space
- Monochromatic with subtle accents
- Clean typography (Inter + JetBrains Mono)
- Minimal borders and shadows
- Focus on content over decoration

---

## 🎨 Color Palette

### Light Mode
```
Background:   #ffffff (pure white)
Surface:      #fafafa (barely gray)
Border:       #e5e5e5 (subtle)
Text:         #171717 (near black)
Secondary:    #737373 (mid gray)
Tertiary:     #a3a3a3 (light gray)
Accent:       #000000 (pure black)
```

### Dark Mode
```
Background:   #000000 (pure black)
Surface:      #0a0a0a (barely lighter)
Border:       #1a1a1a (subtle)
Text:         #ffffff (pure white)
Secondary:    #a3a3a3 (mid gray)
Tertiary:     #525252 (dark gray)
Accent:       #ffffff (pure white)
```

---

## 📐 Typography

### Font Families
- **Sans:** Inter (clean, modern, excellent readability)
- **Mono:** JetBrains Mono (technical, developer-focused)

### Font Sizes
```
Heading 1:   3rem (48px)     - Page titles
Heading 2:   1.5rem (24px)   - Section titles
Body:        1rem (16px)     - Normal text
Small:       0.875rem (14px) - Secondary text
Tiny:        0.75rem (12px)  - Labels, hints
```

### Letter Spacing
- Tighter for larger text (-0.02em to -0.03em)
- Wider for small caps (+0.02em to +0.05em)

---

## 🔲 Components

### Buttons
```css
Primary:   Black bg, white text, subtle hover
Secondary: Transparent bg, border, hover fill
Ghost:     Transparent bg, subtle hover
```

### Cards
```css
Background: White/dark surface
Border:     1px subtle gray
Radius:     12px (rounded-xl)
Padding:    24px (p-6)
Shadow:     None (flat design)
```

### Inputs
```css
Background: White/dark surface
Border:     1px subtle gray
Radius:     8px (rounded-lg)
Padding:    12px 16px
Focus:      2px black/white ring
```

### Badges
```css
Background: Black/white
Text:       White/black (inverted)
Size:       Small, compact
Style:      Pill shape, uppercase
```

---

## 📏 Spacing Scale

```
xs:  4px
sm:  8px
md:  16px
lg:  24px
xl:  32px
2xl: 48px
3xl: 64px
```

**Rule:** Use multiples of 4px for consistency

---

## 🎭 Animations

**Duration:** 150ms (fast, responsive)
**Easing:** ease-out (natural feeling)
**Types:**
- Opacity transitions
- Subtle scale on hover (0.95-1.05)
- Translate for interactions

---

## 📱 Layout Patterns

### Tool Page Layout
```
┌─────────────────────────────────────┐
│ Page Title (centered, large)       │
│ Subtitle (muted)                    │
├─────────────────────────────────────┤
│ Current Info Card (if applicable)   │
├─────────────────────────────────────┤
│ Input Column  │  Output Column      │
│               │                     │
│ [textarea]    │  [results]          │
│ [examples]    │  [stats]            │
└─────────────────────────────────────┘
```

### Home Page Layout
```
┌─────────────────────────────────────┐
│ Hero (centered, huge title)         │
├─────────────────────────────────────┤
│ Tools Grid (cards with hover)       │
├─────────────────────────────────────┤
│ Features (3 columns)                │
└─────────────────────────────────────┘
```

---

## ✅ Design Rules

1. **No gradients** - Flat colors only
2. **No shadows** - Borders for separation
3. **No rainbow** - Monochrome + single accent
4. **Generous spacing** - Let content breathe
5. **Clear hierarchy** - Size, weight, color
6. **Interactive feedback** - Subtle hover states
7. **Consistent rounding** - 8px, 12px, or 16px
8. **Minimal borders** - Only when needed
9. **Uppercase labels** - Small, spaced
10. **Monospace for data** - Technical feel

---

## 🎯 Component Examples

### Button
```tsx
<button className="btn-primary">
  Primary Action
</button>
```

### Card
```tsx
<div className="card">
  {/* Content */}
</div>
```

### Input
```tsx
<textarea className="textarea" />
```

### Stat Display
```tsx
<div className="stat-card">
  <div className="stat-label">Label</div>
  <div className="stat-value">1,234</div>
</div>
```

### Badge
```tsx
<span className="badge-success">Live</span>
```

---

## 🚀 Implementation Checklist

- [x] Update Tailwind config
- [x] Update globals.css
- [x] Update Header
- [x] Update Footer
- [x] Update Home page
- [x] Update Epoch Converter
- [ ] Update JSON Formatter
- [ ] Update Base64 Encoder
- [ ] Update URL Encoder
- [ ] Update JSON Validator
- [ ] Update Dark Mode Toggle

---

## 🎨 Before & After

### Before (Stripe-inspired)
- Blue/purple accents
- Multiple colors
- Soft shadows
- System fonts

### After (Minimalist)
- Pure black/white
- Monochromatic
- Flat/borderless
- Inter font family
- More white space
- Cleaner, simpler

---

**Result:** A modern, professional, minimalist design that puts focus on the tools and content, not decoration.

