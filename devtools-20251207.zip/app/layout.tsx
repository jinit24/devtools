import type { Metadata } from 'next'
import { Inter, Plus_Jakarta_Sans } from 'next/font/google'
import './globals.css'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import { ThemeProvider } from '@/components/shared/ThemeProvider'

const inter = Inter({ 
  subsets: ['latin'], 
  variable: '--font-inter',
  display: 'swap',
})

const jakarta = Plus_Jakarta_Sans({ 
  subsets: ['latin'],
  variable: '--font-jakarta',
  weight: ['400', '500', '600', '700', '800'],
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: {
    default: 'DevUtils - Free Developer Tools | JSON, Base64, URL, Epoch Converter',
    template: '%s | DevUtils'
  },
  description: 'Free online developer tools for JSON formatting, Base64 encoding, URL encoding, and Unix timestamp conversion. Fast, secure, 100% client-side. No signup required.',
  keywords: ['developer tools', 'json formatter', 'epoch converter', 'base64 encoder', 'url encoder', 'json validator', 'online tools', 'free tools'],
  authors: [{ name: 'DevUtils' }],
  creator: 'DevUtils',
  publisher: 'DevUtils',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://devutils.dev',
    siteName: 'DevUtils',
    title: 'DevUtils - Free Developer Tools',
    description: 'Free online developer tools. 100% client-side, secure, fast.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'DevUtils - Free Developer Tools',
    description: 'Free online developer tools. 100% client-side, secure, fast.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    // Add Google Search Console verification here when you have it
    // google: 'your-verification-code',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${jakarta.variable} ${inter.variable} font-sans antialiased`}>
        <ThemeProvider>
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-grow">
              {children}
            </main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

