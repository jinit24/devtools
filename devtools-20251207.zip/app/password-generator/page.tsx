import type { Metadata } from 'next';
import PasswordGenerator from '@/components/tools/PasswordGenerator';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Password Generator - Secure Random Passwords | DevUtils',
  description: 'Free password generator. Generate secure random passwords with customizable options. Strength indicator, bulk generation.',
  keywords: ['password generator', 'random password', 'secure password', 'strong password'],
  alternates: { canonical: 'https://devutils.dev/password-generator' },
};

export default function PasswordGeneratorPage() {
  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={generateToolSchema({ name: 'Password Generator', description: metadata.description as string, url: 'https://devutils.dev/password-generator' })} />
      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">Password Generator</h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">Generate secure random passwords with custom options</p>
      </div>
      <PasswordGenerator />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is a Strong Password?</h2>
          <p className="mb-4">
            A strong password is one that is difficult for humans to guess and for computers to crack using brute-force attacks. Strong passwords typically combine multiple character types (uppercase, lowercase, numbers, and symbols) and are sufficiently long—ideally 12 characters or more.
          </p>
          <p className="mb-4">
            This password generator uses cryptographically secure random number generation to create passwords that are unpredictable and resistant to attacks. The strength indicator analyzes your password based on:
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4">
            <li><strong>Length:</strong> Longer passwords (16+ characters) are exponentially harder to crack.</li>
            <li><strong>Character Variety:</strong> Using all four character types (uppercase, lowercase, numbers, symbols) increases complexity.</li>
            <li><strong>Randomness:</strong> Truly random passwords without patterns or dictionary words are most secure.</li>
            <li><strong>Uniqueness:</strong> Each account should have its own unique password to prevent credential stuffing attacks.</li>
          </ul>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Set Password Length:</strong> Use the slider to choose your desired password length (8-128 characters). We recommend at least 16 characters for maximum security.
            </li>
            <li>
              <strong>Select Character Types:</strong> Check or uncheck the boxes to include uppercase letters, lowercase letters, numbers, and/or symbols. At least one type must be selected.
            </li>
            <li>
              <strong>Generate Password:</strong> A secure password is automatically generated when you load the page. Click "Generate Password" to create a new one with your current settings.
            </li>
            <li>
              <strong>Check Strength:</strong> Review the strength indicator (Weak, Medium, Strong, Very Strong) to ensure your password meets security requirements.
            </li>
            <li>
              <strong>Copy Password:</strong> Use the "Copy" button to quickly copy the generated password to your clipboard.
            </li>
            <li>
              <strong>Generate Multiple:</strong> Use the "Generate 10" button to create a batch of passwords if you need multiple secure passwords at once.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Online Account Security:</strong> Create unique, strong passwords for email, social media, banking, and other online accounts.</li>
            <li><strong>Password Manager:</strong> Generate random passwords to store in password managers like 1Password, LastPass, or Bitwarden.</li>
            <li><strong>Wi-Fi Networks:</strong> Create secure passwords for home or office wireless networks.</li>
            <li><strong>Database Credentials:</strong> Generate strong passwords for database users and administrative accounts.</li>
            <li><strong>API Keys & Tokens:</strong> Create random strings for API authentication and secret tokens.</li>
            <li><strong>Temporary Accounts:</strong> Generate passwords for temporary user accounts or testing purposes.</li>
            <li><strong>System Administration:</strong> Create secure passwords for server access, root accounts, and service accounts.</li>
            <li><strong>Encryption Keys:</strong> Generate random passphrases for file encryption or disk encryption tools.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
