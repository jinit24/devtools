import type { Metadata } from 'next';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Contact Us | DevUtils',
  description: 'Get in touch with the DevUtils team. Report bugs, suggest features, or ask questions.',
  robots: 'index, follow',
  alternates: {
    canonical: 'https://devutils.dev/contact',
  },
};

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-neutral-900 dark:text-white mb-4">
          Contact Us
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 mb-12">
          We'd love to hear from you!
        </p>

        <div className="space-y-8">
          <section className="card p-6">
            <h2 className="text-2xl font-semibold text-neutral-900 dark:text-white mb-4">
              Get in Touch
            </h2>
            <p className="text-neutral-700 dark:text-neutral-300 mb-6">
              Have questions, feedback, or suggestions? We're here to help. Choose the best way to reach us:
            </p>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2 flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  Email
                </h3>
                <p className="text-neutral-700 dark:text-neutral-300 ml-7">
                  For general inquiries, feedback, or support:
                </p>
                <a 
                  href="mailto:jinit245@gmail.com" 
                  className="text-neutral-900 dark:text-white font-mono text-lg underline hover:no-underline ml-7 inline-block mt-1"
                >
                  jinit245@gmail.com
                </a>
              </div>

            </div>
          </section>

          <section className="card p-6">
            <h2 className="text-2xl font-semibold text-neutral-900 dark:text-white mb-4">
              Frequently Asked Questions
            </h2>
            <div className="space-y-6 text-neutral-700 dark:text-neutral-300">
              <div>
                <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-2">
                  Is DevUtils really free?
                </h3>
                <p>
                  Yes! All our tools are 100% free to use with no limits, no signups, and no paywalls. We support the site through non-intrusive display ads.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-2">
                  Is my data safe?
                </h3>
                <p>
                  Absolutely. All tools run entirely in your browser—your data never leaves your device. We don't see, store, or log any of your inputs. Check our <a href="/privacy" className="text-neutral-900 dark:text-white underline hover:no-underline">Privacy Policy</a> for details.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-2">
                  Can I suggest a new tool?
                </h3>
                <p>
                  Yes! We'd love to hear your ideas. Email us at <a href="mailto:hello@devutils.dev" className="text-neutral-900 dark:text-white underline hover:no-underline">hello@devutils.dev</a> or open an issue on GitHub with your suggestion.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-2">
                  I found a bug. How do I report it?
                </h3>
                <p>
                  Please email us at <a href="mailto:jinit245@gmail.com" className="text-neutral-900 dark:text-white underline hover:no-underline">jinit245@gmail.com</a> with details about the bug, including:
                </p>
                <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
                  <li>Which tool you were using</li>
                  <li>What you expected to happen</li>
                  <li>What actually happened</li>
                  <li>Your browser and operating system</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-neutral-900 dark:text-white mb-2">
                  Do you offer an API?
                </h3>
                <p>
                  Not currently. Since all our tools are client-side, there's no backend API to provide.
                </p>
              </div>
            </div>
          </section>

          <section className="card p-6">
            <h2 className="text-2xl font-semibold text-neutral-900 dark:text-white mb-4">
              What to Include
            </h2>
            <p className="text-neutral-700 dark:text-neutral-300 mb-4">
              When emailing us, please include:
            </p>
            <ul className="list-disc list-inside space-y-2 text-neutral-700 dark:text-neutral-300 ml-4">
              <li><strong>For bug reports:</strong> Tool name, browser, OS, steps to reproduce</li>
              <li><strong>For feature requests:</strong> Description of the feature and why it would be useful</li>
              <li><strong>For general feedback:</strong> What you like, what could be better</li>
            </ul>
          </section>

        </div>
      </div>
    </div>
  );
}

