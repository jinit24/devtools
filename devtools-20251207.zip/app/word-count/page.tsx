import type { Metadata } from 'next';
import WordCount from '@/components/tools/WordCount';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Word Counter - Character & Word Count Tool | DevUtils',
  description: 'Free online word counter. Count words, characters, sentences, paragraphs, and get reading time estimates. Fast, secure, 100% client-side, and no signup required.',
  keywords: ['word counter', 'character counter', 'word count', 'character count', 'text counter', 'reading time', 'online tool', 'free'],
  alternates: {
    canonical: 'https://devutils.dev/word-count',
  },
  openGraph: {
    title: 'Word Counter - Character & Word Count Tool | DevUtils',
    description: 'Free online word counter. Count words, characters, sentences, paragraphs, and get reading time estimates.',
    url: 'https://devutils.dev/word-count',
  },
  twitter: {
    title: 'Word Counter - Character & Word Count Tool | DevUtils',
    description: 'Free online word counter. Count words, characters, sentences, paragraphs, and get reading time estimates.',
  },
};

export default function WordCountPage() {
  const toolSchema = generateToolSchema({
    name: 'Word Counter',
    description: metadata.description as string,
    url: metadata.alternates?.canonical as string,
  });

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={toolSchema} />

      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">
          Word Counter
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
          Count words, characters, sentences, and paragraphs. Get reading and speaking time estimates.
        </p>
      </div>

      <WordCount />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is a Word Counter?</h2>
          <p className="mb-4">
            A word counter is a tool that analyzes text and provides various statistics about it, including the number of words, characters, sentences, and paragraphs. It's an essential tool for writers, students, content creators, and anyone who needs to meet specific word or character limits.
          </p>
          <p>
            This tool also provides reading and speaking time estimates based on average reading speeds (200 words per minute) and speaking speeds (130 words per minute), helping you gauge how long it will take to consume your content.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Enter Text:</strong> Type or paste your text into the input area. The tool will automatically analyze it in real-time.
            </li>
            <li>
              <strong>View Statistics:</strong> See instant counts for words, characters (with and without spaces), sentences, paragraphs, and lines.
            </li>
            <li>
              <strong>Check Time Estimates:</strong> View reading and speaking time estimates based on average speeds.
            </li>
            <li>
              <strong>Copy Stats:</strong> Use the copy buttons to quickly grab reading or speaking time estimates.
            </li>
            <li>
              <strong>Try Examples:</strong> Load short or long example texts to see how the tool works.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Academic Writing:</strong> Meet essay, thesis, or assignment word count requirements.</li>
            <li><strong>Content Creation:</strong> Ensure blog posts, articles, or social media posts meet platform limits.</li>
            <li><strong>SEO Optimization:</strong> Track content length for SEO best practices (typically 1,500-2,500 words for blog posts).</li>
            <li><strong>Speech Preparation:</strong> Estimate how long a speech or presentation will take based on word count.</li>
            <li><strong>Translation Work:</strong> Calculate pricing based on word count for translation projects.</li>
            <li><strong>Character Limits:</strong> Stay within character limits for Twitter, SMS, meta descriptions, or other platforms.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}

