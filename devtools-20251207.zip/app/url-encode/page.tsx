import type { Metadata } from 'next';
import UrlEncoderEnhanced from '@/components/tools/UrlEncoderEnhanced';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'URL Encoder & Decoder - Encode/Decode URLs Online | DevUtils',
  description: 'Free online URL encoder and decoder. Encode special characters in URLs for safe transmission and decode them back to readable format. Parse URLs into components and build query strings. Fast, secure, 100% client-side, and no signup required.',
  keywords: ['url encode', 'url decode', 'url converter', 'encode url', 'decode url', 'url parser', 'query string builder', 'online tool', 'free'],
  alternates: {
    canonical: 'https://devutils.dev/url-encode',
  },
  openGraph: {
    title: 'URL Encoder & Decoder - Encode/Decode URLs Online | DevUtils',
    description: 'Free online URL encoder and decoder. Encode special characters in URLs for safe transmission and decode them back. Parse URLs and build query strings.',
    url: 'https://devutils.dev/url-encode',
  },
  twitter: {
    title: 'URL Encoder & Decoder - Encode/Decode URLs Online | DevUtils',
    description: 'Free online URL encoder and decoder. Encode special characters in URLs for safe transmission.',
  },
};

export default function UrlEncoderPage() {
  const toolSchema = generateToolSchema({
    name: 'URL Encoder & Decoder',
    description: metadata.description as string,
    url: metadata.alternates?.canonical as string,
  });

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={toolSchema} />

      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">
          URL Encoder & Decoder
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
          Encode text to URL-safe format or decode URL-encoded strings. Parse URLs and build query strings.
        </p>
      </div>

      <UrlEncoderEnhanced />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is URL Encoding?</h2>
          <p className="mb-4">
            URL encoding (also known as percent-encoding) is a mechanism for encoding information in a Uniform Resource Identifier (URI) under certain circumstances. It is used to replace unsafe ASCII characters with a "%" followed by two hexadecimal digits. URLs can only be sent over the Internet using the ASCII character-set. Characters like spaces, `&`, `=`, `?`, `/`, etc., have special meanings in URLs and must be encoded to be safely transmitted as data.
          </p>
          <p>
            This tool helps you manage URL encoding and decoding, parse complex URLs into their components, and build query strings visually.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Encode/Decode:</strong> Paste your text or URL into the input. Click "Encode" to make it URL-safe, or "Decode" to revert an encoded string.
            </li>
            <li>
              <strong>Parse URL:</strong> Enter a full URL and click "Parse URL" to break it down into its protocol, hostname, path, query parameters, and hash fragment.
            </li>
            <li>
              <strong>Query String Builder:</strong> Use the interactive form to add, edit, or remove query parameters. The tool will automatically build and encode the query string for you.
            </li>
            <li>
              <strong>Validate URL:</strong> Check if a given string is a syntactically valid URL.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Web Development:</strong> Constructing URLs for API requests, redirects, or embedding data in query strings.</li>
            <li><strong>Debugging:</strong> Decoding complex URLs from logs or network traffic to understand their components.</li>
            <li><strong>SEO:</strong> Ensuring clean and correctly formatted URLs for search engine crawlers.</li>
            <li><strong>Security:</strong> Preventing URL injection vulnerabilities by properly encoding user-supplied data.</li>
            <li><strong>Data Sharing:</strong> Creating shareable links with specific parameters.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
