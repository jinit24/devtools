import type { Metadata } from 'next';
import JWTDecoder from '@/components/tools/JWTDecoder';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'JWT Decoder - Decode JWT Tokens | DevUtils',
  description: 'Free JWT decoder. Decode and inspect JWT tokens, view header and payload. Fast, secure, 100% client-side.',
  keywords: ['jwt decoder', 'decode jwt', 'jwt token', 'json web token'],
  alternates: { canonical: 'https://devutils.dev/jwt-decoder' },
};

export default function JWTDecoderPage() {
  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={generateToolSchema({ name: 'JWT Decoder', description: metadata.description as string, url: 'https://devutils.dev/jwt-decoder' })} />
      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">JWT Decoder</h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">Decode and inspect JSON Web Tokens</p>
      </div>
      <JWTDecoder />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is JWT?</h2>
          <p className="mb-4">
            JWT (JSON Web Token) is an open standard (RFC 7519) that defines a compact and self-contained way for securely transmitting information between parties as a JSON object. This information can be verified and trusted because it is digitally signed. JWTs can be signed using a secret (with the HMAC algorithm) or a public/private key pair using RSA or ECDSA.
          </p>
          <p className="mb-4">
            A JWT consists of three parts separated by dots (.):
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4 mb-4">
            <li><strong>Header:</strong> Contains the token type (JWT) and the signing algorithm (e.g., HS256, RS256).</li>
            <li><strong>Payload:</strong> Contains the claims—statements about an entity (typically the user) and additional data like expiration time, issuer, and subject.</li>
            <li><strong>Signature:</strong> Used to verify that the sender of the JWT is who it says it is and to ensure that the message wasn't changed along the way.</li>
          </ul>
          <p>
            Example JWT structure: <code className="font-mono bg-neutral-100 dark:bg-neutral-800 px-2 py-1 rounded text-xs">header.payload.signature</code>
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Paste JWT Token:</strong> Copy your JWT token from your application or API response and paste it into the input field. An example token is pre-loaded to demonstrate the tool.
            </li>
            <li>
              <strong>Decode Token:</strong> The tool automatically decodes the JWT on page load. Click "Decode JWT" to refresh or decode a new token.
            </li>
            <li>
              <strong>View Header:</strong> Inspect the header to see the algorithm used (e.g., HS256) and token type.
            </li>
            <li>
              <strong>Inspect Payload:</strong> View all claims in the payload, including user information, permissions, expiration time, and custom claims.
            </li>
            <li>
              <strong>Check Expiration:</strong> The tool automatically checks if the token has expired based on the "exp" claim and displays the expiration timestamp in a readable format.
            </li>
            <li>
              <strong>Copy Data:</strong> Use the copy buttons to grab the header or payload JSON for further analysis or debugging.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>API Authentication:</strong> Debug authentication issues by inspecting JWT tokens sent in Authorization headers.</li>
            <li><strong>Token Debugging:</strong> Verify token contents, expiration times, and claims when troubleshooting login or access issues.</li>
            <li><strong>Development & Testing:</strong> Inspect test tokens to ensure they contain the correct claims and permissions.</li>
            <li><strong>Security Audits:</strong> Analyze JWT tokens to verify they're using strong algorithms and appropriate expiration times.</li>
            <li><strong>OAuth & SSO:</strong> Decode tokens from OAuth 2.0 flows or Single Sign-On (SSO) systems like Auth0, Okta, or Azure AD.</li>
            <li><strong>Mobile App Development:</strong> Inspect tokens used in mobile apps for API communication.</li>
            <li><strong>Microservices:</strong> Debug service-to-service authentication by examining JWT tokens passed between services.</li>
            <li><strong>Learning:</strong> Understand how JWTs work by decoding real-world tokens and seeing their structure.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
