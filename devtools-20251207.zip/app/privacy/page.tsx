import type { Metadata } from 'next';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Privacy Policy | DevUtils',
  description: 'Privacy policy for DevUtils - how we handle your data and protect your privacy.',
  robots: 'index, follow',
  alternates: {
    canonical: 'https://devutils.dev/privacy',
  },
};

export default function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-neutral-900 dark:text-white mb-4">
          Privacy Policy
        </h1>
        <p className="text-neutral-500 dark:text-neutral-400 mb-8">
          Last updated: December 7, 2025
        </p>

        <div className="space-y-6 text-neutral-700 dark:text-neutral-300">
          <section className="card p-6">
            <h2 className="text-xl font-semibold text-neutral-900 dark:text-white mb-3">
              Overview
            </h2>
            <p>
              DevUtils provides free developer tools that run entirely in your browser. We do not collect, store, or transmit any data you input into our tools. This privacy policy describes how we collect and use information through third-party services for analytics and advertising.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-xl font-semibold text-neutral-900 dark:text-white mb-3">
              What We Collect
            </h2>
            <p className="mb-3">
              <strong>Tool Inputs:</strong> None. All processing happens in your browser. We never see your data.
            </p>
            <p className="mb-3">
              <strong>Analytics:</strong> We use Google Analytics to collect anonymous usage data (pages visited, browser type, general location). This helps us improve the site.
            </p>
            <p>
              <strong>Cookies:</strong> We use cookies for (1) your dark mode preference, (2) Google Analytics, and (3) Google AdSense advertising.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-xl font-semibold text-neutral-900 dark:text-white mb-3">
              Third-Party Services
            </h2>
            <p className="mb-3">
              <strong>Google Analytics:</strong> Collects anonymous usage statistics. <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-neutral-900 dark:text-white underline">Privacy Policy</a>
            </p>
            <p className="mb-3">
              <strong>Google AdSense:</strong> Displays ads and may use cookies for personalization. <a href="https://policies.google.com/technologies/ads" target="_blank" rel="noopener noreferrer" className="text-neutral-900 dark:text-white underline">Privacy Policy</a> | <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-neutral-900 dark:text-white underline">Opt Out</a>
            </p>
            <p>
              <strong>Vercel:</strong> Hosts our website. <a href="https://vercel.com/legal/privacy-policy" target="_blank" rel="noopener noreferrer" className="text-neutral-900 dark:text-white underline">Privacy Policy</a>
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-xl font-semibold text-neutral-900 dark:text-white mb-3">
              Your Choices
            </h2>
            <p className="mb-2">
              • Control cookies through your browser settings
            </p>
            <p className="mb-2">
              • Opt out of personalized ads at <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-neutral-900 dark:text-white underline">Google Ad Settings</a>
            </p>
            <p>
              • Use browser privacy features or ad blockers
            </p>
          </section>

          <section className="card p-6 bg-neutral-50 dark:bg-neutral-800">
            <p className="text-sm">
              <strong>Disclaimer:</strong> This site is provided "as is" without warranties. We are not liable for any damages from use of our tools. Questions? Email jinit245@gmail.com
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

