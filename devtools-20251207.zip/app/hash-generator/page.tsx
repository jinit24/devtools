import type { Metadata } from 'next';
import HashGenerator from '@/components/tools/HashGenerator';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Hash Generator - SHA-1, SHA-256, SHA-512 | DevUtils',
  description: 'Free hash generator. Generate SHA-1, SHA-256, and SHA-512 hashes. Fast, secure, 100% client-side.',
  keywords: ['hash generator', 'sha256', 'sha1', 'sha512', 'crypto hash'],
  alternates: { canonical: 'https://devutils.dev/hash-generator' },
};

export default function HashGeneratorPage() {
  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={generateToolSchema({ name: 'Hash Generator', description: metadata.description as string, url: 'https://devutils.dev/hash-generator' })} />
      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">Hash Generator</h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">Generate cryptographic hashes (SHA-1, SHA-256, SHA-512)</p>
      </div>
      <HashGenerator />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is a Hash?</h2>
          <p className="mb-4">
            A cryptographic hash function is a mathematical algorithm that takes an input (or 'message') and returns a fixed-size string of bytes, typically a hexadecimal number. The output, called a hash or digest, is unique to each unique input—even a tiny change to the input produces a dramatically different hash. This property is known as the "avalanche effect."
          </p>
          <p className="mb-4">
            Hash functions are one-way operations, meaning you cannot reverse a hash to get the original input. This makes them ideal for storing passwords, verifying data integrity, and creating digital signatures. This tool provides three popular SHA (Secure Hash Algorithm) variants:
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4">
            <li><strong>SHA-1:</strong> 160-bit hash (40 hex characters) - Now considered weak for security but still used for checksums.</li>
            <li><strong>SHA-256:</strong> 256-bit hash (64 hex characters) - Recommended for most security applications, part of SHA-2 family.</li>
            <li><strong>SHA-512:</strong> 512-bit hash (128 hex characters) - Most secure option, slower but provides maximum collision resistance.</li>
          </ul>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Enter Text:</strong> Type or paste your text into the input field. An example ("Hello, World!") is pre-loaded to demonstrate the tool.
            </li>
            <li>
              <strong>Generate Hashes:</strong> Click "Generate All Hashes" to compute SHA-1, SHA-256, and SHA-512 hashes simultaneously. All three hashes are generated from the same input for comparison.
            </li>
            <li>
              <strong>View Results:</strong> Each hash appears in its own field with the algorithm name, bit length, and security recommendation.
            </li>
            <li>
              <strong>Copy Hashes:</strong> Use the "Copy" button next to each hash to quickly copy it to your clipboard for use in your applications.
            </li>
            <li>
              <strong>Compare Algorithms:</strong> Notice how the same input produces completely different outputs for each algorithm, and how longer hashes provide more security.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>File Integrity Verification:</strong> Generate checksums to verify files haven't been tampered with during download or transfer.</li>
            <li><strong>Password Storage:</strong> Hash passwords before storing them in databases (though bcrypt or Argon2 are recommended for passwords).</li>
            <li><strong>Digital Signatures:</strong> Create signatures for documents or code to prove authenticity and detect modifications.</li>
            <li><strong>Git Commits:</strong> Git uses SHA-1 hashes to uniquely identify commits, trees, and blobs.</li>
            <li><strong>Cache Keys:</strong> Generate unique cache keys based on content for efficient caching systems.</li>
            <li><strong>Data Deduplication:</strong> Identify duplicate files or data by comparing their hash values.</li>
            <li><strong>API Security:</strong> Create HMAC signatures for API requests to ensure message authenticity.</li>
            <li><strong>Blockchain:</strong> Cryptocurrencies use hash functions extensively for block validation and mining.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
