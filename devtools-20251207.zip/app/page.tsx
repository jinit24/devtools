import Link from 'next/link';
import StructuredData, { generateWebsiteSchema } from '@/components/shared/StructuredData';

const tools = [
  {
    name: 'Epoch Converter',
    description: 'Convert Unix timestamps to dates instantly',
    href: '/epoch-converter',
    icon: '⏱',
  },
  {
    name: 'JSON Formatter',
    description: 'Format, validate, diff, and beautify JSON',
    href: '/json-formatter',
    icon: '{ }',
  },
  {
    name: 'Base64 Encoder',
    description: 'Encode and decode Base64 strings',
    href: '/base64-encode',
    icon: 'B64',
  },
  {
    name: 'URL Encoder',
    description: 'Encode and decode URLs safely',
    href: '/url-encode',
    icon: 'URL',
  },
  {
    name: 'UUID Generator',
    description: 'Generate and validate UUIDs',
    href: '/uuid-generator',
    icon: 'UUID',
  },
  {
    name: 'Hash Generator',
    description: 'Generate SHA-1, SHA-256, SHA-512 hashes',
    href: '/hash-generator',
    icon: '#',
  },
  {
    name: 'JWT Decoder',
    description: 'Decode and validate JWT tokens',
    href: '/jwt-decoder',
    icon: 'JWT',
  },
  {
    name: 'Password Generator',
    description: 'Generate secure random passwords',
    href: '/password-generator',
    icon: '***',
  },
  {
    name: 'Word Count',
    description: 'Count words, characters, and lines',
    href: '/word-count',
    icon: 'Aa',
  },
];

export default function Home() {
  const websiteSchema = generateWebsiteSchema();

  return (
    <div className="container mx-auto px-4 py-16 animate-fade-in">
      <StructuredData data={websiteSchema} />

      {/* Hero Section */}
      <section className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-extrabold text-neutral-900 dark:text-white mb-4 leading-tight">
          Your Essential <span className="text-neutral-900 dark:text-white">Developer Tools</span>
        </h1>
        <p className="text-lg md:text-xl text-neutral-600 dark:text-neutral-400 max-w-3xl mx-auto mb-8">
          Fast, reliable, and 100% client-side tools for everyday development tasks.
          Format JSON, convert Epoch, encode Base64, parse URLs, and more—all for free.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/json-formatter" className="btn-primary shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
            Get Started with JSON
          </Link>
          <Link href="/epoch-converter" className="btn-secondary shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
            Explore Epoch Converter
          </Link>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-neutral-900 dark:text-white text-center mb-10">All Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {tools.map((tool) => (
            <Link
              key={tool.href}
              href={tool.href}
              className="card group flex flex-col items-center text-center p-6 hover:shadow-md hover:border-neutral-200 dark:hover:border-neutral-700 transform hover:-translate-y-1 transition-all duration-200"
            >
              <div className="text-5xl mb-4 transition-transform group-hover:scale-110 group-hover:rotate-3 duration-200">
                {tool.icon}
              </div>
              <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2 group-hover:text-neutral-900 dark:group-hover:text-white transition-colors">
                {tool.name}
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-4 flex-grow">
                {tool.description}
              </p>
              <span className="text-neutral-900 dark:text-white font-medium flex items-center gap-1">
                Use Tool
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="text-center mb-16">
        <h2 className="text-3xl font-bold text-neutral-900 dark:text-white mb-10">Why Choose DevUtils?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="card p-6 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-black dark:bg-white flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-white dark:text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2">Lightning Fast</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm">
              All tools run directly in your browser, ensuring instant results without server delays.
            </p>
          </div>
          <div className="card p-6 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-black dark:bg-white flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-white dark:text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2">100% Private</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm">
              Your data never leaves your browser. We don't store, log, or transmit any of your input.
            </p>
          </div>
          <div className="card p-6 flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-black dark:bg-white flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-white dark:text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2">Beautiful & Intuitive</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm">
              Enjoy a clean, modern UI designed for developers, with dark mode support and a focus on UX.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center card p-10 max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-neutral-900 dark:text-white mb-4">Ready to Boost Your Productivity?</h2>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 mb-8">
          Start using DevUtils today—no signups, no ads, just powerful tools at your fingertips.
        </p>
        <Link href="/json-formatter" className="btn-primary btn-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
          Start Using Tools Now
        </Link>
      </section>
    </div>
  );
}
