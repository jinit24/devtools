import type { Metadata } from 'next';
import JsonFormatterEnhanced from '@/components/tools/JsonFormatterEnhanced';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'JSON Formatter & Validator - Beautify, Minify, Sort JSON Online | DevUtils',
  description: 'Free JSON formatter with 6 operations: format, minify, sort keys, escape, unescape, validate. See depth, keys, size stats. Fast, secure, 100% client-side, and no signup required.',
  keywords: ['json formatter', 'json beautifier', 'json minifier', 'json validator', 'format json', 'minify json', 'sort json', 'escape json', 'unescape json', 'online json tool', 'free'],
  alternates: {
    canonical: 'https://devutils.dev/json-formatter',
  },
  openGraph: {
    title: 'JSON Formatter & Validator - Beautify, Minify, Sort JSON Online | DevUtils',
    description: 'Free JSON formatter with 6 operations: format, minify, sort keys, escape, unescape, validate. See depth, keys, size stats.',
    url: 'https://devutils.dev/json-formatter',
  },
  twitter: {
    title: 'JSON Formatter & Validator - Beautify, Minify, Sort JSON Online | DevUtils',
    description: 'Free JSON formatter with 6 operations: format, minify, sort keys, escape, unescape, validate.',
  },
};

export default function JsonFormatterPage() {
  const toolSchema = generateToolSchema({
    name: 'JSON Formatter & Validator',
    description: metadata.description as string,
    url: metadata.alternates?.canonical as string,
  });

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={toolSchema} />

      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">
          JSON Formatter & Validator
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
          Instantly format, minify, sort, escape, unescape, and validate your JSON data.
        </p>
      </div>

      <JsonFormatterEnhanced />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is JSON?</h2>
          <p className="mb-4">
            JSON (JavaScript Object Notation) is a lightweight data-interchange format. It is easy for humans to read and write. It is easy for machines to parse and generate. It is based on a subset of the JavaScript Programming Language, Standard ECMA-262 3rd Edition - December 1999. JSON is a text format that is completely language independent but uses conventions that are familiar to programmers of the C-family of languages, including C, C++, C#, Java, JavaScript, Perl, Python, and many others. These properties make JSON an ideal data-interchange language.
          </p>
          <p>
            This tool helps you work with JSON by providing various operations to make it more readable, compact, or to ensure its correctness.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Input JSON:</strong> Paste your JSON data into the "Input JSON" textarea.
            </li>
            <li>
              <strong>Choose Operation:</strong> Select an operation like "Format", "Minify", "Sort Keys", "Escape", "Unescape", or "Validate".
            </li>
            <li>
              <strong>View Output:</strong> The result will appear in the "Output JSON" textarea. If validating, a success or error message will be displayed.
            </li>
            <li>
              <strong>Stats:</strong> Observe real-time statistics about your JSON, including line count, depth, key count, and size.
            </li>
            <li>
              <strong>Copy:</strong> Use the copy button to quickly grab the output.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>API Development:</strong> Quickly format or validate JSON payloads for requests and responses.</li>
            <li><strong>Debugging:</strong> Make unreadable, minified JSON from logs or network requests human-readable.</li>
            <li><strong>Data Transfer:</strong> Minify JSON to reduce payload size for faster data transfer.</li>
            <li><strong>Configuration Files:</strong> Ensure your JSON configuration files are correctly structured.</li>
            <li><strong>Code Generation:</strong> Escape JSON for embedding into string literals in various programming languages.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
