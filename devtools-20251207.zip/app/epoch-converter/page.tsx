import type { Metadata } from 'next';
import EpochConverter from '@/components/tools/EpochConverter';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Epoch Converter - Unix Timestamp Converter | DevUtils',
  description: 'Convert Unix timestamps to dates instantly. Supports seconds, milliseconds, microseconds, and nanoseconds. Fast, secure, 100% client-side, and no signup required.',
  keywords: ['epoch converter', 'unix timestamp', 'timestamp converter', 'epoch to date', 'date to epoch', 'timestamp to date converter'],
  alternates: {
    canonical: 'https://devutils.dev/epoch-converter',
  },
  openGraph: {
    title: 'Epoch Converter - Unix Timestamp Converter | DevUtils',
    description: 'Convert Unix timestamps to dates instantly. Supports seconds, milliseconds, microseconds, and nanoseconds.',
    url: 'https://devutils.dev/epoch-converter',
  },
  twitter: {
    title: 'Epoch Converter - Unix Timestamp Converter | DevUtils',
    description: 'Convert Unix timestamps to dates instantly. Supports seconds, milliseconds, microseconds, and nanoseconds.',
  },
};

export default function EpochConverterPage() {
  const toolSchema = generateToolSchema({
    name: 'Epoch Converter',
    description: metadata.description as string,
    url: metadata.alternates?.canonical as string,
  });

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={toolSchema} />

      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">
          Epoch Converter
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
          Convert Unix timestamps to human-readable dates and vice versa. Supports seconds, milliseconds, microseconds, and nanoseconds.
        </p>
      </div>

      <EpochConverter />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is Epoch Time?</h2>
          <p className="mb-4">
            Epoch time, also known as Unix timestamp, is a system for describing a point in time. It is the number of seconds that have elapsed since the Unix epoch, which is January 1, 1970, 00:00:00 Coordinated Universal Time (UTC), minus leap seconds. It is widely used in computing and programming because it simplifies date and time calculations and storage.
          </p>
          <p>
            This tool allows you to effortlessly convert between these numerical timestamps and human-readable dates, supporting various levels of precision including seconds, milliseconds, microseconds, and nanoseconds.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Timestamp to Date:</strong> Paste your Unix timestamp into the input field. The tool will automatically detect its precision and convert it instantly. You'll see the corresponding date in GMT/UTC, Local Time, and a relative format.
            </li>
            <li>
              <strong>Date to Timestamp:</strong> Use the date and time picker to select a specific date and time. The tool will instantly convert it to Epoch values in various precisions.
            </li>
            <li>
              <strong>Current Timestamp:</strong> The "Current Timestamp" section provides live, auto-updating Epoch values in all supported precisions. Click any value to use it as input.
            </li>
            <li>
              <strong>Copy Results:</strong> Use the convenient copy buttons next to each output value to quickly grab the converted data.
            </li>
            <li>
              <strong>Examples:</strong> Utilize the example buttons (Seconds, Milliseconds, etc.) to quickly populate the input with sample timestamps for testing different formats.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>API Debugging:</strong> Quickly convert timestamps from API responses or webhooks to understand event times.</li>
            <li><strong>Log Analysis:</strong> Transform server log timestamps into readable formats for easier debugging and analysis.</li>
            <li><strong>Database Management:</strong> Work with timestamp fields in databases, converting them to and from Epoch for various operations.</li>
            <li><strong>System Synchronization:</strong> Ensure consistent timekeeping across different systems by converting timestamps to a common format.</li>
            <li><strong>Data Migration:</strong> Handle timestamp conversions during data import or export processes.</li>
            <li><strong>Forensics:</strong> Analyze file system or network event timestamps.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
