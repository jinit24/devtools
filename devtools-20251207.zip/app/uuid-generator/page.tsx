import type { Metadata } from 'next';
import UUIDGenerator from '@/components/tools/UUIDGenerator';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'UUID Generator - Generate & Validate UUIDs | DevUtils',
  description: 'Free UUID (GUID) generator. Generate v4 UUIDs, bulk generation, and validate UUID format. Fast, secure, 100% client-side.',
  keywords: ['uuid generator', 'guid generator', 'uuid v4', 'generate uuid', 'validate uuid'],
  alternates: { canonical: 'https://devutils.dev/uuid-generator' },
};

export default function UUIDGeneratorPage() {
  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={generateToolSchema({ name: 'UUID Generator', description: metadata.description as string, url: 'https://devutils.dev/uuid-generator' })} />
      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">UUID Generator</h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">Generate and validate UUIDs (Universally Unique Identifiers)</p>
      </div>
      <UUIDGenerator />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is a UUID?</h2>
          <p className="mb-4">
            A UUID (Universally Unique Identifier), also known as a GUID (Globally Unique Identifier), is a 128-bit number used to uniquely identify information in computer systems. UUIDs are standardized by the Open Software Foundation (OSF) as part of the Distributed Computing Environment (DCE).
          </p>
          <p className="mb-4">
            The UUID v4 format uses random or pseudo-random numbers to generate identifiers. The probability of generating duplicate UUIDs is extremely low—approximately 1 in 2^122, making them practically unique for most applications. This makes UUIDs ideal for distributed systems where generating unique identifiers without central coordination is necessary.
          </p>
          <p>
            A typical UUID looks like this: <code className="font-mono bg-neutral-100 dark:bg-neutral-800 px-2 py-1 rounded">550e8400-e29b-41d4-a716-446655440000</code>. The format is 8-4-4-4-12 hexadecimal digits separated by hyphens.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Generate Single UUID:</strong> A new UUID v4 is automatically generated when you open the page. Click "Generate New UUID" to create another one. Use the "Copy" button to quickly copy it to your clipboard.
            </li>
            <li>
              <strong>Bulk Generation:</strong> Enter the number of UUIDs you need (up to 100) and click "Generate X UUIDs". All UUIDs will appear in a text area where you can copy them all at once.
            </li>
            <li>
              <strong>Validate UUID:</strong> Paste any UUID into the validation field and click "Validate UUID" to check if it's properly formatted according to RFC 4122 standards.
            </li>
            <li>
              <strong>UUID Analysis:</strong> View the breakdown of the current UUID showing its components (Time Low, Time Mid, Version, Variant, and Node).
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Database Primary Keys:</strong> Use UUIDs as unique identifiers for database records across distributed systems without coordination.</li>
            <li><strong>API Development:</strong> Generate unique request IDs, transaction IDs, or resource identifiers in REST APIs.</li>
            <li><strong>File Naming:</strong> Create unique filenames for uploads or temporary files to avoid conflicts.</li>
            <li><strong>Session IDs:</strong> Generate unique session identifiers for user authentication and tracking.</li>
            <li><strong>Distributed Systems:</strong> Ensure uniqueness across multiple servers or microservices without a central authority.</li>
            <li><strong>Testing & Development:</strong> Generate test data with guaranteed unique identifiers.</li>
            <li><strong>Message Queues:</strong> Create unique message IDs for tracking in queue systems like RabbitMQ or Kafka.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
