import type { Metadata } from 'next';
import Base64EncoderEnhanced from '@/components/tools/Base64EncoderEnhanced';
import StructuredData, { generateToolSchema } from '@/components/shared/StructuredData';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'Base64 Encoder & Decoder - Encode/Decode Online | DevUtils',
  description: 'Free online Base64 encoder and decoder. Convert text to Base64 and Base64 to text instantly in your browser. Supports URL-safe encoding and auto-detection. Fast, secure, 100% client-side, and no signup required.',
  keywords: ['base64 encode', 'base64 decode', 'base64 converter', 'encode base64', 'decode base64', 'url safe base64', 'online tool', 'free'],
  alternates: {
    canonical: 'https://devutils.dev/base64-encode',
  },
  openGraph: {
    title: 'Base64 Encoder & Decoder - Encode/Decode Online | DevUtils',
    description: 'Free online Base64 encoder and decoder. Convert text to Base64 and Base64 to text instantly. Supports URL-safe encoding and auto-detection.',
    url: 'https://devutils.dev/base64-encode',
  },
  twitter: {
    title: 'Base64 Encoder & Decoder - Encode/Decode Online | DevUtils',
    description: 'Free online Base64 encoder and decoder. Convert text to Base64 and Base64 to text instantly.',
  },
};

export default function Base64EncoderPage() {
  const toolSchema = generateToolSchema({
    name: 'Base64 Encoder & Decoder',
    description: metadata.description as string,
    url: metadata.alternates?.canonical as string,
  });

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <StructuredData data={toolSchema} />

      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 dark:text-white mb-3">
          Base64 Encoder & Decoder
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 max-w-2xl mx-auto">
          Encode text to Base64 or decode Base64 strings back to text. Supports URL-safe encoding and auto-detection.
        </p>
      </div>

      <Base64EncoderEnhanced />

      {/* Educational Content */}
      <div className="mt-12 space-y-8 text-neutral-700 dark:text-neutral-300 max-w-4xl mx-auto">
        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">What is Base64?</h2>
          <p className="mb-4">
            Base64 is a group of binary-to-text encoding schemes that represent binary data in an ASCII string format by translating it into a radix-64 representation. It is commonly used to embed binary data (like images or other files) within text-based formats such as JSON, XML, or email. It ensures that the data remains intact without modification during transport.
          </p>
          <p>
            This tool provides a fast and secure way to encode and decode Base64 strings entirely within your browser, ensuring your data privacy.
          </p>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">How to Use This Tool</h2>
          <ol className="list-decimal list-inside space-y-3">
            <li>
              <strong>Input:</strong> Paste your text or Base64 string into the "Input" textarea.
            </li>
            <li>
              <strong>Encode/Decode:</strong> Click "Encode" to convert plain text to Base64, or "Decode" to convert a Base64 string back to plain text.
            </li>
            <li>
              <strong>URL-Safe:</strong> Check the "URL-Safe" option if you need to encode/decode Base64 strings that are safe for use in URLs (replaces `+` with `-` and `/` with `_`).
            </li>
            <li>
              <strong>Auto-Detect:</strong> The tool will attempt to detect if your input is a valid Base64 string.
            </li>
            <li>
              <strong>Stats:</strong> View character counts and size comparisons to understand the encoding overhead.
            </li>
          </ol>
        </section>

        <section className="card p-6">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-4">Common Use Cases</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Embedding Data:</strong> Embed small images or other binary assets directly into HTML, CSS, or JSON.</li>
            <li><strong>Email Attachments:</strong> Base64 is often used to encode email attachments for reliable transmission.</li>
            <li><strong>API Tokens:</strong> Encode API keys or authentication tokens for safe transmission in HTTP headers or URLs.</li>
            <li><strong>Data Obfuscation:</strong> Simple obfuscation of data (not encryption) for storage or transmission.</li>
            <li><strong>Cross-Platform Compatibility:</strong> Ensure data integrity when transferring between systems with different character encoding standards.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
