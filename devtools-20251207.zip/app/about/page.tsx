import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  metadataBase: new URL('https://devutils.dev'),
  title: 'About Us | DevUtils',
  description: 'Learn about DevUtils - free, open-source developer tools designed for privacy and simplicity.',
  robots: 'index, follow',
  alternates: {
    canonical: 'https://devutils.dev/about',
  },
};

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12 animate-fade-in">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-neutral-900 dark:text-white mb-4">
          About DevUtils
        </h1>
        <p className="text-lg text-neutral-600 dark:text-neutral-400 mb-12">
          Free, fast, and privacy-focused developer tools.
        </p>

        <div className="space-y-8 text-neutral-700 dark:text-neutral-300">

          <section className="card p-6">
            <h2 className="text-2xl font-semibold text-neutral-900 dark:text-white mb-4">
              Our Tools
            </h2>
            <p className="mb-4">
              We currently offer 9 essential developer tools:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <Link href="/epoch-converter" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">Epoch Converter</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Unix timestamp conversion</p>
              </Link>
              <Link href="/json-formatter" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">JSON Formatter</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Format, validate, and diff JSON</p>
              </Link>
              <Link href="/base64-encode" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">Base64 Encoder</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Encode and decode Base64</p>
              </Link>
              <Link href="/url-encode" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">URL Encoder</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Encode and parse URLs</p>
              </Link>
              <Link href="/uuid-generator" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">UUID Generator</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Generate unique identifiers</p>
              </Link>
              <Link href="/hash-generator" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">Hash Generator</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">SHA-1, SHA-256, SHA-512</p>
              </Link>
              <Link href="/jwt-decoder" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">JWT Decoder</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Decode JSON Web Tokens</p>
              </Link>
              <Link href="/password-generator" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">Password Generator</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Secure random passwords</p>
              </Link>
              <Link href="/word-count" className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">
                <h3 className="font-semibold text-neutral-900 dark:text-white">Word Count</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">Count words and characters</p>
              </Link>
            </div>
            <p>
              More tools are in development! Have a suggestion? <Link href="/contact" className="text-neutral-900 dark:text-white underline hover:no-underline">Let us know</Link>.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-2xl font-semibold text-neutral-900 dark:text-white mb-4">
              Contact
            </h2>
            <p>
              Questions or feedback? <Link href="/contact" className="text-neutral-900 dark:text-white underline hover:no-underline">Contact us</Link> or email jinit245@gmail.com
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

