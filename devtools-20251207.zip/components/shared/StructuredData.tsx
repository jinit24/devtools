export default function StructuredData({ data }: { data: any }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}

export function generateToolSchema(tool: {
  name: string
  description: string
  url: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: tool.name,
    description: tool.description,
    url: tool.url,
    applicationCategory: 'DeveloperApplication',
    operatingSystem: 'Web Browser',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
    },
    featureList: [
      '100% client-side processing',
      'No data sent to servers',
      'Instant results',
      'Dark mode support',
    ],
  }
}

export function generateWebsiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'DevUtils',
    description: 'Free online developer tools',
    url: 'https://devutils.dev',
    potentialAction: {
      '@type': 'SearchAction',
      target: 'https://devutils.dev/?q={search_term_string}',
      'query-input': 'required name=search_term_string',
    },
  }
}

export function generateOrganizationSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'DevUtils',
    url: 'https://devutils.dev',
    logo: 'https://devutils.dev/logo.png',
    sameAs: [
      // Add social media links when available
    ],
  }
}

