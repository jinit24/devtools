import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="border-t border-neutral-100 dark:border-dark-border bg-white dark:bg-dark-bg mt-20">
      <div className="container mx-auto px-6 md:px-8 py-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-sm text-neutral-500 dark:text-neutral-500">
            © {new Date().getFullYear()} DevUtils. All rights reserved.
          </div>
          
          <div className="flex items-center gap-6">
            <Link 
              href="/about"
              className="text-sm text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              About
            </Link>
            <Link 
              href="/contact"
              className="text-sm text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Contact
            </Link>
            <Link 
              href="/privacy"
              className="text-sm text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Privacy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
