import Link from 'next/link'
import DarkModeToggle from '@/components/shared/DarkModeToggle'

const tools = [
  { name: 'Epoch', href: '/epoch-converter' },
  { name: 'JSON', href: '/json-formatter' },
  { name: 'Base64', href: '/base64-encode' },
  { name: 'URL', href: '/url-encode' },
  { name: 'UUID', href: '/uuid-generator' },
  { name: 'Hash', href: '/hash-generator' },
  { name: 'JWT', href: '/jwt-decoder' },
  { name: 'Password', href: '/password-generator' },
  { name: 'Word Count', href: '/word-count' },
]

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-neutral-100 dark:border-dark-border bg-white/80 dark:bg-dark-bg/80 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-xl font-bold text-neutral-900 dark:text-white tracking-tight hover:opacity-70 transition-opacity">
            DevUtils
          </Link>
          
          <nav className="flex items-center gap-6">
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-6">
              {tools.map((tool) => (
                <Link
                  key={tool.href}
                  href={tool.href}
                  className="text-sm font-medium text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors"
                >
                  {tool.name}
                </Link>
              ))}
            </div>
            
            <DarkModeToggle />
          </nav>
        </div>
      </div>
    </header>
  )
}
