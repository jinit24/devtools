'use client'

import { useState, useEffect } from 'react'
import { formatJSON, minifyJSON, sortJSON, escapeJSON, unescapeJSON, validateJSON, diffJSON, getJSONStats, JSONStats } from '@/lib/tools/jsonFormatter'

export default function JsonFormatterEnhanced() {
  const [input, setInput] = useState('{"name":"John Doe","age":30,"city":"New York","active":true}')
  const [input2, setInput2] = useState('')
  const [output, setOutput] = useState('')
  const [inputStats, setInputStats] = useState<JSONStats | null>(null)
  const [outputStats, setOutputStats] = useState<JSONStats | null>(null)
  const [error, setError] = useState<string>('')
  const [showDiff, setShowDiff] = useState(false)

  useEffect(() => {
    // Auto-format on mount to show example
    const result = formatJSON(input, 2)
    if (result.success) {
      setOutput(result.result)
    }
  }, [])

  useEffect(() => {
    if (input) {
      const stats = getJSONStats(input)
      setInputStats(stats)
    } else {
      setInputStats(null)
    }
  }, [input])

  useEffect(() => {
    if (output) {
      const stats = getJSONStats(output)
      setOutputStats(stats)
    } else {
      setOutputStats(null)
    }
  }, [output])

  const handleFormat = () => {
    const result = formatJSON(input, 2)
    if (result.success) {
      setOutput(result.result)
      setError('')
    } else {
      setError(result.error || 'Invalid JSON')
      setOutput('')
    }
  }

  const handleMinify = () => {
    const result = minifyJSON(input)
    if (result.success) {
      setOutput(result.result)
      setError('')
    } else {
      setError(result.error || 'Invalid JSON')
      setOutput('')
    }
  }

  const handleSort = () => {
    const result = sortJSON(input)
    if (result.success) {
      setOutput(result.result)
      setError('')
    } else {
      setError(result.error || 'Invalid JSON')
      setOutput('')
    }
  }

  const handleEscape = () => {
    const result = escapeJSON(input)
    setOutput(result.result)
    setError('')
  }

  const handleUnescape = () => {
    const result = unescapeJSON(input)
    setOutput(result.result)
    setError('')
  }

  const handleValidate = () => {
    const result = validateJSON(input)
    if (result.success) {
      setOutput(formatJSON(input, 2).result)
      setError('')
    } else {
      setError(result.error || 'Invalid JSON')
      setOutput('')
    }
  }

  const handleDiff = () => {
    if (!input2) {
      setError('Please provide a second JSON to compare')
      return
    }
    const result = diffJSON(input, input2)
    if (result.success && result.diff) {
      const diffOutput = [
        result.diff.added.length > 0 ? `Added:\n${result.diff.added.join('\n')}` : '',
        result.diff.removed.length > 0 ? `Removed:\n${result.diff.removed.join('\n')}` : '',
        result.diff.modified.length > 0 ? `Modified:\n${result.diff.modified.join('\n')}` : '',
      ].filter(Boolean).join('\n\n') || 'No differences found'
      
      setOutput(diffOutput)
      setError('')
    } else {
      setError(result.error || 'Error comparing JSON')
      setOutput('')
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Input</h2>
            {inputStats && (
              <span className="text-xs text-neutral-500">{inputStats.size}</span>
            )}
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                JSON Data
              </label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder='{"key": "value"}'
                className="textarea min-h-[300px]"
              />
            </div>

            <div className="divider"></div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Operations
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={handleFormat} className="btn-secondary text-sm">
                  Format
                </button>
                <button onClick={handleMinify} className="btn-secondary text-sm">
                  Minify
                </button>
                <button onClick={handleSort} className="btn-secondary text-sm">
                  Sort Keys
                </button>
                <button onClick={handleValidate} className="btn-secondary text-sm">
                  Validate
                </button>
                <button onClick={handleEscape} className="btn-secondary text-sm">
                  Escape
                </button>
                <button onClick={handleUnescape} className="btn-secondary text-sm">
                  Unescape
                </button>
              </div>
            </div>

            <div className="divider"></div>

            <div>
              <label className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400 cursor-pointer mb-3">
                <input
                  type="checkbox"
                  checked={showDiff}
                  onChange={(e) => setShowDiff(e.target.checked)}
                  className="w-4 h-4 rounded border-neutral-300 dark:border-dark-border"
                />
                Compare with second JSON
              </label>
              
              {showDiff && (
                <div className="space-y-2">
                  <textarea
                    value={input2}
                    onChange={(e) => setInput2(e.target.value)}
                    placeholder='{"second": "json"}'
                    className="textarea min-h-[100px]"
                  />
                  <button onClick={handleDiff} className="btn-primary text-sm w-full">
                    Compare JSONs
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Input Stats */}
          {inputStats && (
            <div className="card">
              <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Input Stats</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Lines</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{inputStats.lines}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Depth</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{inputStats.depth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Keys</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{inputStats.keys}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Size</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{inputStats.size}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Output */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Output</h2>
            {output && (
              <button onClick={() => copyToClipboard(output)} className="btn-ghost text-xs py-1 px-2">
                Copy
              </button>
            )}
          </div>

          <div className="card min-h-[300px]">
            {error ? (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="text-xs font-medium uppercase tracking-wide text-red-600 dark:text-red-400 mb-2">
                  Error
                </div>
                <div className="text-sm text-red-700 dark:text-red-300 font-mono">
                  {error}
                </div>
              </div>
            ) : output ? (
              <div>
                <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                  Result
                </label>
                <textarea
                  value={output}
                  readOnly
                  className="textarea min-h-[300px]"
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-center py-12">
                <p className="text-sm text-neutral-400 dark:text-neutral-600">
                  Choose an operation to see results
                </p>
              </div>
            )}
          </div>

          {/* Output Stats */}
          {outputStats && !error && (
            <div className="card">
              <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Output Stats</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Lines</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{outputStats.lines}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Depth</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{outputStats.depth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Keys</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{outputStats.keys}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Size</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{outputStats.size}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
