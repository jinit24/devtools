'use client'

import { useState, useEffect } from 'react'
import { getWordCountStats, WordCountStats } from '@/lib/tools/wordCount'

export default function WordCount() {
  const [text, setText] = useState('Type or paste your text here to analyze word count, character count, and more.')
  const [stats, setStats] = useState<WordCountStats | null>(null)

  useEffect(() => {
    const newStats = getWordCountStats(text)
    setStats(newStats)
  }, [text])

  const copyToClipboard = (value: string | number) => {
    navigator.clipboard.writeText(value.toString())
  }

  const loadExample = (type: 'short' | 'long') => {
    if (type === 'short') {
      setText('The quick brown fox jumps over the lazy dog. This is a simple sentence for testing.')
    } else {
      setText(`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`)
    }
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Input</h2>
            {stats && (
              <span className="text-xs text-neutral-500">{stats.words} words</span>
            )}
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Your Text
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type or paste your text here..."
                className="textarea min-h-[400px]"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                <button onClick={() => loadExample('short')} className="btn-ghost text-xs py-1.5 px-3">
                  Short Example
                </button>
                <button onClick={() => loadExample('long')} className="btn-ghost text-xs py-1.5 px-3">
                  Long Example
                </button>
                <button onClick={() => setText('')} className="btn-ghost text-xs py-1.5 px-3">
                  Clear
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Statistics</h2>
          </div>

          {stats && (
            <div className="space-y-4">
              {/* Primary Stats */}
              <div className="card">
                <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-4">Counts</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="stat-card">
                    <div className="stat-label">Words</div>
                    <div className="stat-value text-2xl">{stats.words.toLocaleString()}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">Characters</div>
                    <div className="stat-value text-2xl">{stats.characters.toLocaleString()}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">No Spaces</div>
                    <div className="stat-value">{stats.charactersNoSpaces.toLocaleString()}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">Sentences</div>
                    <div className="stat-value">{stats.sentences.toLocaleString()}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">Paragraphs</div>
                    <div className="stat-value">{stats.paragraphs.toLocaleString()}</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-label">Lines</div>
                    <div className="stat-value">{stats.lines.toLocaleString()}</div>
                  </div>
                </div>
              </div>

              {/* Time Estimates */}
              <div className="card">
                <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-4">Time Estimates</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-neutral-100 dark:border-dark-border">
                    <span className="text-sm text-neutral-600 dark:text-neutral-400">Reading Time</span>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-900 dark:text-white">{stats.readingTime}</span>
                      <button onClick={() => copyToClipboard(stats.readingTime)} className="btn-ghost text-xs py-0.5 px-2">
                        Copy
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-sm text-neutral-600 dark:text-neutral-400">Speaking Time</span>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-900 dark:text-white">{stats.speakingTime}</span>
                      <button onClick={() => copyToClipboard(stats.speakingTime)} className="btn-ghost text-xs py-0.5 px-2">
                        Copy
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Averages */}
              <div className="card">
                <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-4">Averages</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Words per sentence</span>
                    <span className="font-semibold text-neutral-900 dark:text-white">
                      {stats.sentences > 0 ? Math.round(stats.words / stats.sentences) : 0}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Characters per word</span>
                    <span className="font-semibold text-neutral-900 dark:text-white">
                      {stats.words > 0 ? Math.round(stats.charactersNoSpaces / stats.words) : 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

