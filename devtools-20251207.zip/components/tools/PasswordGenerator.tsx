'use client'
import { useState, useEffect } from 'react'
import { generatePassword, calculatePasswordStrength, generateBulkPasswords } from '@/lib/tools/passwordGenerator'

export default function PasswordGenerator() {
  const [password, setPassword] = useState('')
  const [length, setLength] = useState(16)
  const [options, setOptions] = useState({ uppercase: true, lowercase: true, numbers: true, symbols: true })
  const [bulkCount, setBulkCount] = useState(5)
  const [bulkPasswords, setBulkPasswords] = useState<string[]>([])

  useEffect(() => {
    // Generate initial password on mount
    const pwd = generatePassword({ length, ...options })
    setPassword(pwd)
  }, [])
  
  const generate = () => {
    const pwd = generatePassword({ length, ...options })
    setPassword(pwd)
  }

  const handleBulk = () => {
    const pwds = generateBulkPasswords(bulkCount, { length, ...options })
    setBulkPasswords(pwds)
  }

  const strength = password ? calculatePasswordStrength(password) : null
  const copy = (text: string) => navigator.clipboard.writeText(text)

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">Options</h2></div>
          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Length: {length}</label>
              <input type="range" min="8" max="64" value={length} onChange={(e) => setLength(parseInt(e.target.value))} className="w-full" />
            </div>
            <div className="space-y-2">
              {[
                { key: 'uppercase', label: 'Uppercase (A-Z)' },
                { key: 'lowercase', label: 'Lowercase (a-z)' },
                { key: 'numbers', label: 'Numbers (0-9)' },
                { key: 'symbols', label: 'Symbols (!@#$)' }
              ].map(opt => (
                <label key={opt.key} className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={options[opt.key as keyof typeof options]} onChange={(e) => setOptions({ ...options, [opt.key]: e.target.checked })} className="w-4 h-4 rounded" />
                  {opt.label}
                </label>
              ))}
            </div>
            <button onClick={generate} className="btn-primary w-full">Generate Password</button>
            <div className="divider"></div>
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-2">Bulk Generate</label>
              <div className="flex gap-2">
                <input type="number" value={bulkCount} onChange={(e) => setBulkCount(Math.min(parseInt(e.target.value) || 5, 50))} min="1" max="50" className="input w-20" />
                <button onClick={handleBulk} className="btn-secondary flex-1">Generate {bulkCount}</button>
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">Password</h2></div>
          {password && (
            <div className="card space-y-4">
              <div className="flex gap-2">
                <input value={password} readOnly className="input flex-1 font-mono" />
                <button onClick={() => copy(password)} className="btn-ghost text-xs px-3">Copy</button>
              </div>
              {strength && (
                <div>
                  <div className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-2">Strength: {strength.label}</div>
                  <div className="h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${(strength.score / 4) * 100}%`, backgroundColor: strength.color }}></div>
                  </div>
                </div>
              )}
            </div>
          )}
          {bulkPasswords.length > 0 && (
            <div className="card">
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Bulk Passwords</label>
              <textarea value={bulkPasswords.join('\n')} readOnly className="textarea min-h-[200px] text-xs" />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
