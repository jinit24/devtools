'use client'

import { useState, useEffect } from 'react'
import { encodeBase64, decodeBase64, getBase64Stats, detectBase64, Base64Stats } from '@/lib/tools/base64Encoder'

export default function Base64EncoderEnhanced() {
  const [input, setInput] = useState('Hello, World!')
  const [output, setOutput] = useState('')
  const [urlSafe, setUrlSafe] = useState(false)
  const [stats, setStats] = useState<Base64Stats | null>(null)

  useEffect(() => {
    // Auto-encode on mount to show example
    const encoded = encodeBase64(input, urlSafe)
    setOutput(encoded)
  }, [])

  useEffect(() => {
    if (input && output) {
      const newStats = getBase64Stats(input, output, urlSafe)
      setStats(newStats)
    } else {
      setStats(null)
    }
  }, [input, output, urlSafe])

  const handleEncode = () => {
    const encoded = encodeBase64(input, urlSafe)
    setOutput(encoded)
  }

  const handleDecode = () => {
    const decoded = decodeBase64(input)
    setOutput(decoded)
  }

  const handleAutoDetect = () => {
    if (detectBase64(input)) {
      handleDecode()
    } else {
      handleEncode()
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const loadExample = (type: 'text' | 'base64') => {
    if (type === 'text') {
      setInput('Hello, World! This is a Base64 encoding example.')
    } else {
      setInput('SGVsbG8sIFdvcmxkISBUaGlzIGlzIGEgQmFzZTY0IGVuY29kaW5nIGV4YW1wbGUu')
    }
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Input</h2>
            {input && (
              <span className="text-xs text-neutral-500">{input.length} chars</span>
            )}
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Text / Base64
              </label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter text or Base64..."
                className="textarea min-h-[200px]"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                <button onClick={() => loadExample('text')} className="btn-ghost text-xs py-1.5 px-3">
                  Example Text
                </button>
                <button onClick={() => loadExample('base64')} className="btn-ghost text-xs py-1.5 px-3">
                  Example Base64
                </button>
              </div>
            </div>

            <div className="divider"></div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Operations
              </label>
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={handleEncode} className="btn-secondary text-sm">
                    Encode
                  </button>
                  <button onClick={handleDecode} className="btn-secondary text-sm">
                    Decode
                  </button>
                </div>
                <button onClick={handleAutoDetect} className="btn-secondary text-sm w-full">
                  Auto Detect
                </button>
                <label className="flex items-center gap-2 text-sm text-neutral-600 dark:text-neutral-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={urlSafe}
                    onChange={(e) => setUrlSafe(e.target.checked)}
                    className="w-4 h-4 rounded border-neutral-300 dark:border-dark-border"
                  />
                  URL-Safe Encoding
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Output */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Output</h2>
            {output && (
              <button onClick={() => copyToClipboard(output)} className="btn-ghost text-xs py-1 px-2">
                Copy
              </button>
            )}
          </div>

          <div className="card min-h-[200px]">
            {output ? (
              <div>
                <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                  Result
                </label>
                <textarea
                  value={output}
                  readOnly
                  className="textarea min-h-[200px]"
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-center py-12">
                <p className="text-sm text-neutral-400 dark:text-neutral-600">
                  Click Encode or Decode to see results
                </p>
              </div>
            )}
          </div>

          {/* Stats */}
          {stats && (
            <div className="card">
              <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Comparison</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Input Size</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{stats.inputSize}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Output Size</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{stats.outputSize}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Size Change</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{stats.compressionRatio}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Encoding</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{stats.encoding === 'url-safe' ? 'URL-Safe' : 'Standard'}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
