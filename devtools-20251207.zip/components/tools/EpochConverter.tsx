'use client'

import { useState, useEffect } from 'react'
import { convertEpochToDate, convertDateToEpoch, getCurrentTimestampDetails, type TimestampDetails } from '@/lib/tools/epochConverter'

export default function EpochConverter() {
  const [timestamp, setTimestamp] = useState('')
  const [timestampResult, setTimestampResult] = useState<TimestampDetails | null>(null)
  const [dateInput, setDateInput] = useState('')
  const [dateResult, setDateResult] = useState<number | null>(null)
  const [currentTime, setCurrentTime] = useState<TimestampDetails | null>(null)

  // Initialize with current timestamp on mount and update every second
  useEffect(() => {
    const currentDetails = getCurrentTimestampDetails()
    setCurrentTime(currentDetails)
    
    // Set current timestamp as initial example (in milliseconds)
    if (!timestamp) {
      setTimestamp(currentDetails.milliseconds.toString())
    }
    
    const interval = setInterval(() => {
      setCurrentTime(getCurrentTimestampDetails())
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  // Auto-convert timestamp to date when input changes
  useEffect(() => {
    if (timestamp.trim()) {
      const result = convertEpochToDate(timestamp)
      setTimestampResult(result)
    } else {
      setTimestampResult(null)
    }
  }, [timestamp])

  // Auto-convert date to timestamp when input changes
  useEffect(() => {
    if (dateInput) {
      const result = convertDateToEpoch(dateInput)
      setDateResult(result)
    } else {
      setDateResult(null)
    }
  }, [dateInput])

  const loadExample = (type: 'seconds' | 'milliseconds' | 'microseconds' | 'nanoseconds') => {
    const examples = {
      seconds: '1701234567',
      milliseconds: '1701234567000',
      microseconds: '1701234567000000',
      nanoseconds: '1701234567000000000',
    }
    setTimestamp(examples[type])
  }

  const loadCurrentTime = (format: 'seconds' | 'milliseconds' | 'microseconds' | 'nanoseconds') => {
    if (!currentTime) return
    const values = {
      seconds: currentTime.seconds.toString(),
      milliseconds: currentTime.milliseconds.toString(),
      microseconds: currentTime.microseconds.toString(),
      nanoseconds: currentTime.nanoseconds.toString(),
    }
    setTimestamp(values[format])
  }

  const copyToClipboard = (text: string | number) => {
    navigator.clipboard.writeText(text.toString())
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Current Timestamp */}
      {currentTime && (
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-sm font-semibold tracking-tight text-neutral-900 dark:text-white">Current Time</h3>
            <span className="badge-success flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-white dark:bg-black rounded-full animate-pulse"></span>
              Live
            </span>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button onClick={() => loadCurrentTime('seconds')} className="stat-card text-left cursor-pointer">
              <div className="stat-label">Seconds</div>
              <div className="stat-value text-base">{currentTime.seconds}</div>
            </button>
            <button onClick={() => loadCurrentTime('milliseconds')} className="stat-card text-left cursor-pointer">
              <div className="stat-label">Milliseconds</div>
              <div className="stat-value text-base">{currentTime.milliseconds}</div>
            </button>
            <button onClick={() => loadCurrentTime('microseconds')} className="stat-card text-left cursor-pointer">
              <div className="stat-label">Microseconds</div>
              <div className="stat-value text-sm">{currentTime.microseconds}</div>
            </button>
            <button onClick={() => loadCurrentTime('nanoseconds')} className="stat-card text-left cursor-pointer">
              <div className="stat-label">Nanoseconds</div>
              <div className="stat-value text-xs">{currentTime.nanoseconds}</div>
            </button>
          </div>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Input</h2>
          </div>

          <div className="card space-y-6">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Timestamp
              </label>
              <textarea
                value={timestamp}
                onChange={(e) => setTimestamp(e.target.value)}
                placeholder="Enter unix timestamp..."
                className="textarea min-h-[100px]"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                <button onClick={() => loadExample('seconds')} className="btn-ghost text-xs py-1.5 px-3">
                  Seconds
                </button>
                <button onClick={() => loadExample('milliseconds')} className="btn-ghost text-xs py-1.5 px-3">
                  Milliseconds
                </button>
                <button onClick={() => loadExample('microseconds')} className="btn-ghost text-xs py-1.5 px-3">
                  Microseconds
                </button>
                <button onClick={() => loadExample('nanoseconds')} className="btn-ghost text-xs py-1.5 px-3">
                  Nanoseconds
                </button>
              </div>
            </div>

            <div className="divider"></div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Date & Time
              </label>
              <input
                type="datetime-local"
                value={dateInput}
                onChange={(e) => setDateInput(e.target.value)}
                className="input"
              />
            </div>
          </div>
        </div>

        {/* Output */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Output</h2>
            {(timestampResult || dateResult !== null) && (
              <span className="text-xs text-neutral-500">Auto-converted</span>
            )}
          </div>

          <div className="card min-h-[400px]">
            {/* Timestamp to Date Output */}
            {timestampResult && timestamp && (
              <div className="space-y-6">
                <div>
                  <div className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-2">
                    Detected Format
                  </div>
                  <div className="text-sm font-medium text-neutral-900 dark:text-white">
                    {timestampResult.detectedFormat}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-2">
                    Relative Time
                  </div>
                  <div className="text-xl font-semibold text-neutral-900 dark:text-white">
                    {timestampResult.relativeTime}
                  </div>
                </div>

                <div className="divider"></div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs font-medium uppercase tracking-wide text-neutral-500">
                      GMT / UTC
                    </div>
                    <button onClick={() => copyToClipboard(timestampResult.gmtString)} className="btn-ghost text-xs py-1 px-2">
                      Copy
                    </button>
                  </div>
                  <div className="text-sm font-mono text-neutral-700 dark:text-neutral-300 break-all">
                    {timestampResult.gmtString}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs font-medium uppercase tracking-wide text-neutral-500">
                      Local Time
                    </div>
                    <button onClick={() => copyToClipboard(timestampResult.localString)} className="btn-ghost text-xs py-1 px-2">
                      Copy
                    </button>
                  </div>
                  <div className="text-sm font-mono text-neutral-700 dark:text-neutral-300 break-all">
                    {timestampResult.localString}
                  </div>
                </div>
              </div>
            )}

            {/* Date to Timestamp Output */}
            {dateResult !== null && dateInput && !timestamp && (
              <div className="space-y-6">
                <div>
                  <div className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-2">
                    Selected Date
                  </div>
                  <div className="text-sm text-neutral-700 dark:text-neutral-300">
                    {new Date(dateInput).toLocaleString()}
                  </div>
                </div>

                <div className="divider"></div>

                <div className="space-y-3">
                  {[
                    { label: 'Seconds', value: dateResult },
                    { label: 'Milliseconds', value: dateResult * 1000 },
                    { label: 'Microseconds', value: dateResult * 1000000 },
                    { label: 'Nanoseconds', value: dateResult * 1000000000 },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between py-2">
                      <div className="text-xs font-medium uppercase tracking-wide text-neutral-500">
                        {item.label}
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-mono font-semibold text-neutral-900 dark:text-white">
                          {item.value}
                        </div>
                        <button onClick={() => copyToClipboard(item.value)} className="btn-ghost text-xs py-1 px-2">
                          Copy
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Empty State */}
            {!timestamp && !dateInput && (
              <div className="flex items-center justify-center h-full text-center py-12">
                <div>
                  <p className="text-sm text-neutral-400 dark:text-neutral-600">
                    Enter a timestamp or select a date
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
