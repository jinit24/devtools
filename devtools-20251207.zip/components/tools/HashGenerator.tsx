'use client'
import { useState, useEffect } from 'react'
import { generateSHA1, generateSHA256, generateSHA512 } from '@/lib/tools/hashGenerator'

export default function HashGenerator() {
  const [input, setInput] = useState('Hello, World!')
  const [hashes, setHashes] = useState({ sha1: '', sha256: '', sha512: '' })

  useEffect(() => {
    generateAll()
  }, [])

  const generateAll = async () => {
    const [sha1, sha256, sha512] = await Promise.all([
      generateSHA1(input),
      generateSHA256(input),
      generateSHA512(input)
    ])
    setHashes({ sha1, sha256, sha512 })
  }

  const copy = (text: string) => navigator.clipboard.writeText(text)

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">Input</h2></div>
          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Text to Hash</label>
              <textarea 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                className="textarea min-h-[200px]" 
                placeholder="Enter text to generate hashes..."
              />
              <button onClick={generateAll} className="btn-primary w-full mt-3">Generate All Hashes</button>
            </div>
          </div>

          {/* Input Info */}
          <div className="card">
            <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Input Info</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Characters</span>
                <span className="font-semibold text-neutral-900 dark:text-white">{input.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Bytes</span>
                <span className="font-semibold text-neutral-900 dark:text-white">{new Blob([input]).size}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Algorithms</span>
                <span className="font-semibold text-neutral-900 dark:text-white">3</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">Hashes</h2></div>
          <div className="space-y-3">
            {[
              { type: 'SHA-1', value: hashes.sha1, length: 40, description: '160-bit hash' },
              { type: 'SHA-256', value: hashes.sha256, length: 64, description: '256-bit hash (recommended)' },
              { type: 'SHA-512', value: hashes.sha512, length: 128, description: '512-bit hash (most secure)' },
            ].map(hash => (
              <div key={hash.type} className="card">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">{hash.type}</label>
                    <div className="text-xs text-neutral-400 dark:text-neutral-600">{hash.description}</div>
                  </div>
                  {hash.value && (
                    <button onClick={() => copy(hash.value)} className="btn-ghost text-xs py-0.5 px-2">Copy</button>
                  )}
                </div>
                <input 
                  value={hash.value} 
                  readOnly 
                  className="input font-mono text-xs" 
                  placeholder={`Generate to see ${hash.type}...`}
                />
                {hash.value && (
                  <div className="text-xs text-neutral-500 mt-1">
                    {hash.length} characters (hex)
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
