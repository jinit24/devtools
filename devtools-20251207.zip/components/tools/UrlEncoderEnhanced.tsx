'use client'

import { useState, useEffect } from 'react'
import { encodeURL, decodeURL, parseURL, buildQueryString, validateURL } from '@/lib/tools/urlEncoder'

export default function UrlEncoderEnhanced() {
  const [input, setInput] = useState('https://example.com/path?name=John Doe&age=30')
  const [output, setOutput] = useState('')
  const [parsedURL, setParsedURL] = useState<any>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    // Auto-encode on mount to show example
    const encoded = encodeURL(input)
    setOutput(encoded)
  }, [])

  const handleEncode = () => {
    const encoded = encodeURL(input)
    setOutput(encoded)
    setError('')
  }

  const handleDecode = () => {
    const decoded = decodeURL(input)
    setOutput(decoded)
    setError('')
  }

  const handleParse = () => {
    const parsed = parseURL(input)
    if (parsed) {
      setParsedURL(parsed)
      setError('')
    } else {
      setError('Invalid URL format')
      setParsedURL(null)
    }
  }

  const handleValidate = () => {
    const isValid = validateURL(input)
    setOutput(isValid ? '✓ Valid URL' : '✗ Invalid URL')
    setError(isValid ? '' : 'URL validation failed')
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const loadExample = (type: 'url' | 'encoded') => {
    if (type === 'url') {
      setInput('https://example.com/path?name=John Doe&age=30')
    } else {
      setInput('https://example.com/path?name=John%20Doe&age=30')
    }
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Input</h2>
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                URL / Text
              </label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter URL or text..."
                className="textarea min-h-[150px]"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                <button onClick={() => loadExample('url')} className="btn-ghost text-xs py-1.5 px-3">
                  Example URL
                </button>
                <button onClick={() => loadExample('encoded')} className="btn-ghost text-xs py-1.5 px-3">
                  Encoded URL
                </button>
              </div>
            </div>

            <div className="divider"></div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Operations
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={handleEncode} className="btn-secondary text-sm">
                  Encode
                </button>
                <button onClick={handleDecode} className="btn-secondary text-sm">
                  Decode
                </button>
                <button onClick={handleParse} className="btn-secondary text-sm">
                  Parse URL
                </button>
                <button onClick={handleValidate} className="btn-secondary text-sm">
                  Validate
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Output */}
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Output</h2>
            {output && !parsedURL && (
              <button onClick={() => copyToClipboard(output)} className="btn-ghost text-xs py-1 px-2">
                Copy
              </button>
            )}
          </div>

          <div className="card min-h-[400px]">
            {error ? (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="text-xs font-medium uppercase tracking-wide text-red-600 dark:text-red-400 mb-2">
                  Error
                </div>
                <div className="text-sm text-red-700 dark:text-red-300">
                  {error}
                </div>
              </div>
            ) : parsedURL ? (
              <div className="space-y-4">
                <div className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                  Parsed Components
                </div>
                {Object.entries(parsedURL).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-start py-2 border-b border-neutral-100 dark:border-dark-border last:border-0">
                    <span className="text-xs font-medium uppercase tracking-wide text-neutral-500">{key}</span>
                    <span className="text-sm font-mono text-neutral-900 dark:text-white break-all ml-4 text-right">
                      {String(value) || '-'}
                    </span>
                  </div>
                ))}
              </div>
            ) : output ? (
              <div>
                <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                  Result
                </label>
                <textarea
                  value={output}
                  readOnly
                  className="textarea min-h-[150px]"
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-center py-12">
                <p className="text-sm text-neutral-400 dark:text-neutral-600">
                  Choose an operation to see results
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
