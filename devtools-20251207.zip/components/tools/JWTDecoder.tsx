'use client'
import { useState, useEffect } from 'react'
import { decodeJWT, formatTimestamp } from '@/lib/tools/jwtDecoder'

const EXAMPLE_JWT = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJleHAiOjk5OTk5OTk5OTl9.8VQr8RnLqZjKEy_7CqGhPwRqCWnDUSLqGdYjKNGJE1E'

export default function JWTDecoder() {
  const [token, setToken] = useState(EXAMPLE_JWT)
  const [decoded, setDecoded] = useState<any>(null)

  useEffect(() => {
    if (token) {
      const result = decodeJWT(token)
      setDecoded(result)
    }
  }, [])

  const handleDecode = () => {
    const result = decodeJWT(token)
    setDecoded(result)
  }

  const copy = (text: string) => navigator.clipboard.writeText(text)

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">JWT Token</h2></div>
          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Paste JWT</label>
              <textarea 
                value={token} 
                onChange={(e) => setToken(e.target.value)} 
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." 
                className="textarea min-h-[200px] text-xs" 
              />
              <button onClick={handleDecode} className="btn-primary w-full mt-3">Decode JWT</button>
            </div>
          </div>

          {/* Token Info */}
          {decoded && decoded.header && (
            <div className="card">
              <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Token Info</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Algorithm</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{decoded.header.alg || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Type</span>
                  <span className="font-semibold text-neutral-900 dark:text-white">{decoded.header.typ || '-'}</span>
                </div>
                {decoded.payload?.iat && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Issued At</span>
                    <span className="font-semibold text-neutral-900 dark:text-white text-xs">{formatTimestamp(decoded.payload.iat)}</span>
                  </div>
                )}
                {decoded.payload?.exp && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">Expires</span>
                    <span className="font-semibold text-neutral-900 dark:text-white text-xs">{formatTimestamp(decoded.payload.exp)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Status</span>
                  <span className={`font-semibold ${decoded.isValid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {decoded.isValid ? '✓ Valid' : '✗ Invalid'}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="section-header"><h2 className="section-title">Decoded</h2></div>
          {decoded && (
            <div className="space-y-4">
              {!decoded.isValid && decoded.error && (
                <div className="card p-4 bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800">
                  <div className="text-sm font-semibold text-red-700 dark:text-red-300">{decoded.error}</div>
                </div>
              )}
              {decoded.header && (
                <div className="card">
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Header</label>
                    <button onClick={() => copy(JSON.stringify(decoded.header, null, 2))} className="btn-ghost text-xs py-0.5 px-2">Copy</button>
                  </div>
                  <textarea value={JSON.stringify(decoded.header, null, 2)} readOnly className="textarea min-h-[100px] text-xs" />
                </div>
              )}
              {decoded.payload && (
                <div className="card">
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Payload</label>
                    <button onClick={() => copy(JSON.stringify(decoded.payload, null, 2))} className="btn-ghost text-xs py-0.5 px-2">Copy</button>
                  </div>
                  <textarea value={JSON.stringify(decoded.payload, null, 2)} readOnly className="textarea min-h-[180px] text-xs" />
                </div>
              )}
              {decoded.signature && (
                <div className="card">
                  <label className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3 block">Signature (Base64)</label>
                  <input value={decoded.signature} readOnly className="input font-mono text-xs" />
                  <div className="text-xs text-neutral-500 mt-2">
                    {decoded.signature.length} characters
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
