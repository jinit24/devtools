'use client'

import { useState, useEffect } from 'react'
import { generateUUIDv4, generateBulkUUIDs, validateUUID } from '@/lib/tools/uuidGenerator'

export default function UUIDGenerator() {
  const [uuid, setUuid] = useState('')
  const [bulkCount, setBulkCount] = useState(10)
  const [bulkUUIDs, setBulkUUIDs] = useState<string[]>([])
  const [validateInput, setValidateInput] = useState('')
  const [isValid, setIsValid] = useState<boolean | null>(null)

  useEffect(() => {
    // Generate initial UUID on mount
    setUuid(generateUUIDv4())
  }, [])

  const generateNew = () => setUuid(generateUUIDv4())
  
  const handleBulkGenerate = () => {
    const uuids = generateBulkUUIDs(Math.min(bulkCount, 100))
    setBulkUUIDs(uuids)
  }

  const handleValidate = () => {
    setIsValid(validateUUID(validateInput))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Generate</h2>
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                UUID v4
              </label>
              <div className="flex gap-2">
                <input value={uuid} readOnly className="input flex-1 font-mono text-sm" />
                <button onClick={() => copyToClipboard(uuid)} className="btn-ghost text-xs px-3">
                  Copy
                </button>
              </div>
              <button onClick={generateNew} className="btn-primary w-full mt-3">
                Generate New UUID
              </button>
            </div>

            <div className="divider"></div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                Bulk Generate
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="number"
                  value={bulkCount}
                  onChange={(e) => setBulkCount(Math.min(parseInt(e.target.value) || 10, 100))}
                  min="1"
                  max="100"
                  className="input w-24"
                />
                <button onClick={handleBulkGenerate} className="btn-secondary flex-1 text-sm">
                  Generate {bulkCount} UUIDs
                </button>
              </div>
              {bulkUUIDs.length > 0 && (
                <div>
                  <textarea
                    value={bulkUUIDs.join('\n')}
                    readOnly
                    className="textarea min-h-[150px] text-xs"
                  />
                  <button onClick={() => copyToClipboard(bulkUUIDs.join('\n'))} className="btn-ghost text-xs w-full mt-2">
                    Copy All
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* UUID Info */}
          <div className="card">
            <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">UUID Info</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Format</span>
                <span className="font-semibold text-neutral-900 dark:text-white">8-4-4-4-12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Total Characters</span>
                <span className="font-semibold text-neutral-900 dark:text-white">36</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Hex Digits</span>
                <span className="font-semibold text-neutral-900 dark:text-white">32</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Version</span>
                <span className="font-semibold text-neutral-900 dark:text-white">4 (Random)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="section-header">
            <h2 className="section-title">Validate</h2>
          </div>

          <div className="card space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">
                UUID to Validate
              </label>
              <textarea
                value={validateInput}
                onChange={(e) => setValidateInput(e.target.value)}
                placeholder="Paste UUID to validate..."
                className="textarea min-h-[100px]"
              />
              <button onClick={handleValidate} className="btn-primary w-full mt-3">
                Validate UUID
              </button>
            </div>

            {isValid !== null && (
              <div className={`p-4 rounded-lg border ${isValid ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800' : 'bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800'}`}>
                <div className="flex items-start gap-2">
                  <span className="text-2xl">{isValid ? '✓' : '✗'}</span>
                  <div>
                    <div className={`text-sm font-semibold ${isValid ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                      {isValid ? 'Valid UUID' : 'Invalid UUID Format'}
                    </div>
                    {isValid && validateInput && (
                      <div className="text-xs text-green-600 dark:text-green-400 mt-2 space-y-1">
                        <div>Format: Correct (8-4-4-4-12)</div>
                        <div>Version: {validateInput[14]}</div>
                        <div>Variant: RFC 4122</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Current UUID Analysis */}
          {uuid && (
            <div className="card">
              <h3 className="text-xs font-medium uppercase tracking-wide text-neutral-500 mb-3">Current UUID Analysis</h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Time Low</span>
                  <span className="text-neutral-900 dark:text-white">{uuid.substring(0, 8)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Time Mid</span>
                  <span className="text-neutral-900 dark:text-white">{uuid.substring(9, 13)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Version</span>
                  <span className="text-neutral-900 dark:text-white">{uuid.substring(14, 18)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Variant</span>
                  <span className="text-neutral-900 dark:text-white">{uuid.substring(19, 23)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">Node</span>
                  <span className="text-neutral-900 dark:text-white">{uuid.substring(24)}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
